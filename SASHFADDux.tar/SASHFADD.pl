#!/usr/local/bin/perl5
#
################################################################################################
#												
# SASHFADD.pl - SAS Hot Fix Analysis, Download and Deployment Tool				
# 												
# SAS Technical Support										
# Copyright (c) 2019 by SAS Institute Inc., Cary, NC, USA. 					
# All Rights Reserved.										
#												
# Notes:  											
# 1) SASHFADD for Windows hosts is pre-compiled and delivered as SASHFADD.exe			
# 2) SASHFADD for UNIX hosts requires PERL 5							
# 3) Use SASHFADD.cfg to configure SASHFADD processing and output				
# 4) The following files must be present in the same directory as SASHFADD			
#	SASHFADD.cfg										
#	DeploymentRegistry.txt									
#	SAS[93-94]_HFADD_data.xml (downloaded when SASHFADD is launched)			
# 5) Usage: https://tshf.sas.com/techsup/download/hotfix/HF2/SASHFADD_usage.pdf			
################################################################################################

use strict;

#	INITIALIZE
our %tool;
$tool{version} = "2.2"; # The tool version.. MUST MATCH THE VERSION # in SAS*_HFADD_data.xml
$tool{release} = "2";	# Release of this "version" of SASHFADD for minor updates.  Does not require new download of SASHFADD
$tool{print_version} = $tool{version};
if($tool{release} ne '0')
	{$tool{print_version} .= ".$tool{release}";}
	
print "\n\n\n** SAS Hot Fix Analysis, Download and Deployment Tool Ver. $tool{print_version} **\n\n";

#	GLOBAL ARRAYS and HASHES
our @REGKEYARRAY;
our @DL_KEYS;
our @HFIDHSTARRAY;
our @HFIDHSTALERTDEPARRAY;
our @MD5ARRAY;
our @MD5ARRAYALERT;
our @COMMENTARRAY;
our @NOMITARRAY;
our @NONENGLISH;
our @NLS2BYTE;
our %host;
our %nls;
our %urls;
our %ftpx;
our %announce;
our %comments;
our %pslash;
our %output;
our %dirname;
our %filename;
our %filehandle;

#	HASHES FOR DEPLOYMENT REGISTRY VALUES
our %regHost;
our %regProduct;
our %regVersion;
our %regDisplayName;
our %regMaintenance;
our %regHotfix;
our %reg_ref;
our %reg_error;

#	HASHES FOR SAS*_HFADD_data.xml VALUES
our %hfdata;
our %hfdata_ref;
our %dl_hfids;
our %noreport;

#	Initial HASH seeds and Platform Specific scalars
$pslash{win} = "\\";
$pslash{unix} = "/";
our $PLATFORM = "unix"; # UNIX or WIN.  The platform for this port of SASHFADD
our $EOF = "EOF\n";

$output{citationcount} = 0;

#	GLOBAL SCALARS
our $ERROR = 0;
our $HOSTGROUP;
our $CURTIME = localtime(time());
our $TSTAMP = time();
our $OUTPUTNAME;
our $RCOLSPAN = 5;
our $USEDCOMMENTS;
our $SUPPRESSEDHFIDS;
our $AT_LEAST_ONE_ALERT_FLAG = 0;
our $ALERT_README = &SASHFADD_alert_readme_content;
our $OPENDATAFILEERROR;
our $HFIDHSTLIST;
our $USER_SUPPLIED_SCRIPT_HEADER;
our $USER_SUPPLIED_COMMAND_LINE_OPTIONS;

#	CONFIGURATION DEFAULTS AND LOADING
our %config;
$config{sasrelfrozen} = 0;
$config{silent} = 0;
$config{alert_only_scripting} = 0;
$config{all_eligible_scripting} = 0;
$config{sftp_secure_scripting} = 0;
$config{basic_ftp_scripting} = 0;
$config{manual_data} = 0;
$config{english_only} = 0;
$config{date_format_1} = 0;
$config{modified_script_header} = 0;
$config{add_command_line_options} = 0;

&SASHFADD_load_config;
our $DISPLAYTSTAMP = &SASHFADD_generate_displaytstamp;

if($config{modified_script_header} eq '1')
	{&SASHFADD_load_modified_script_header;}

if($config{add_command_line_options} eq '1')
	{&SASHFADD_load_command_line_options;}

# 	BEGIN MAIN		
if($config{silent} eq '0')
	{&SASHFADD_outputname_prompt;}
my $hostlist = &SASHFADD_load_deployment_registry;
if($config{manual_data} eq '0' && $hostlist)
	{my $rcftp = &SASHFADD_HFADD_data_xml_download_script_generate_and_run;}
&SASHFADD_load_SAS_HFADD_data($hostlist);

our $USAGE_GUIDE_LINK = "$urls{u2}/SASHFADD_usage.pdf";
our $TOOL_LINK        = "$urls{u2}/SASHFADD.html";
&SASHFADD_load_comments;

&SASHFADD_create_output_structure;
my $versionokflag = &SASHFADD_check_version_compatibility;
if($versionokflag eq '1' && $config{sasrel})
	{	
	&SASHFADD_compare_01;
	&SASHFADD_hot_fix_process_01;
	if($config{all_eligible_scripting} ne '1')
		{&SASHFADD_alert_dependencies_01;}
	&SASHFADD_hot_fix_download_script_gen;
	&SASHFADD_sdm_readme_gen;
	&SASHFADD_md5_list_gen;
	}
&SASHFADD_initialize_report;
&SASHFADD_print_report;
&SASHFADD_installed_hot_fix_manifest;
&SASHFADD_print_log;

my $errornote;
if($ERROR eq '1')
	{$errornote = "\nAt least one ERROR/WARNING was recorded!\nReview the SASHFADD_LOG for more information.";}
print "\n\nSASHFADD processing complete!$errornote \n\n";
print "SASHFADD output written to directory:\n";
print " -> ${OUTPUTNAME}_${DISPLAYTSTAMP}\n\n";
if($PLATFORM eq 'win' && $config{silent} eq '0')
	{
	print "Press \"Enter\" to end this program.";
	my $exitcode = <>;
	}
exit(0);

#	END MAIN		

#														
#														
#	Determining Products and Available Hot Fixes								
#														
#														

################################################################################################################
### SASHFADD_load_deployment_registry										
### load the DeploymentRegistry.txt data which was outputted from sas.tools.viewregistry.jar.			
###
sub SASHFADD_load_deployment_registry
{
my $deploymentregistry = "DeploymentRegistry.txt";
if(open(deploymentregistry, "$deploymentregistry"))
	{$output{log} .= ">> $deploymentregistry open\n";}
else
	{
	$ERROR = 1;
	my $errorMessage = "\n**********\n>> %%% ERROR: Unable to open $deploymentregistry\n";
	$errorMessage .= ">> A DeploymentRegistry.txt file MUST be in the same directory as SASHFADD.\n";
	$errorMessage .= ">> The DeploymentRegistry.txt contains information about your SAS deployment that is required for SASHFADD to provide an accurate hot fix analysis.\n";
	$errorMessage .= ">> See the SASHFADD Usage Guide for instructions on how to generate a DeploymentRegistry.txt.\n";
	$output{log} .= $errorMessage;
	print $errorMessage;
	}

$output{log} .= ">> Licensed Products in the Deployment Registry\n";

my $host;
my $hostlist;
my $product;
my $regversion;
my $regdisplay;
my $display_version;
my $hotfixdata;
my $hotfixentry;
my $nullskip;
my $suppressed_hfids;
my $valid_product_count = 0;
my $instqualtoolflag = 0;
my $line = <deploymentregistry>;
while(!eof(deploymentregistry))
	{
	$line =~ s/\r\n/\n/;
	chomp($line);
	if($line =~ /Host:/)
		{
		$host = $';
		$host =~ s/\s+//g;
		$host = "\L$host\E";
		if($hostlist !~ /$host\,/)
			{$hostlist .= "$host,";}
		}
	elsif($line =~ /Product: /)
		{
		$product = $';
		$product = "\L$product\E";
		}
	elsif($line =~ /    Version: /)
		{$regversion = $';}
	elsif($line =~ / Display Name: /)
		{$regdisplay = $';}
	elsif($line =~ /Display Version: /)
		{
		$display_version = $';
		if($product eq 'instqualtool')
			{$instqualtoolflag = $display_version;}
		}
	elsif($line =~ /Hot Fix Entry: /)
		{
		my $hotfixdata = $';
		if($hotfixdata =~ /^Hotfix/)
			{
			my @splitA = split(/Hotfix /, $hotfixdata);
			$hotfixdata = $splitA[1];
			if($hotfixdata =~ /_/)
				{
				my @splitB = split(/_/, $hotfixdata);
				my $suppress = $splitB[0];
				$hotfixentry .= " $suppress ";
				$suppressed_hfids .= "     - Hot Fix reporting suppression trigger \"_\" found: $hotfixdata\n";
				$SUPPRESSEDHFIDS .=  " ${suppress}_${host} "; 
				}
			else
				{$hotfixentry .= " ${hotfixdata}_${host} ";}
			}
		}
	elsif($line =~ /\-{10,}/)
		{
		my $maintenance = "0";
		my $prodversion = $display_version;
		if($display_version =~ /_M/i)
			{
			$prodversion = $`;
			$maintenance = $';
			}

		my $key = "$host~$product~$prodversion~$maintenance";		
		
		if($host && $product && $regversion && $regdisplay && $display_version && $regdisplay !~ /^null$/i)
			{		
			push(@REGKEYARRAY, $key);
			$reg_ref{$key} .= $hotfixentry;
			$regHost{$key} = $host;
			$regProduct{$key} = $product;
			$regVersion{$key} = $regversion;
			$regDisplayName{$key} = $regdisplay;
			$regHotfix{$key} .= " $hotfixentry ";
			$regMaintenance{$key} = $maintenance;
			$output{log} .= "     [$regHost{$key}] $regDisplayName{$key} $regVersion{$key}_M$regMaintenance{$key} ($regProduct{$key}):$regHotfix{$key}\n";
			$valid_product_count++;
			}
		elsif($regdisplay =~ /^null$/i)
			{$nullskip .= "     - null Display Name encountered... skipped! [$product|$regversion|$regdisplay|$display_version]\n";}
		else
			{
			$reg_error{$key} .= ">> %%% WARNING: The following product has missing variables in $deploymentregistry:\n";
			$reg_error{$key} .= "                         Host: $host\n";
			$reg_error{$key} .= "                      Product: $product\n";
			$reg_error{$key} .= "                      Version: $regversion\n";
			$reg_error{$key} .= "                 Display Name: $regdisplay\n";
			$reg_error{$key} .= "              Display Version: $display_version\n";
			$reg_error{incomplete_list} .= " $key ";
			}
		$host = undef;
		$product = undef;
		$regversion = undef;
		$regdisplay = undef;
		$display_version = undef;
		$hotfixdata = undef;
		$hotfixentry = undef;
		}

	$line = <deploymentregistry>;
	}
close(deploymentregistry);

if($instqualtoolflag =~ /9\.3/)
	{&SASHFADD_set_release_vars('93','instqualtool');}
elsif($instqualtoolflag =~ /9\.4/)
	{&SASHFADD_set_release_vars('94','instqualtool');}
elsif(!$config{sasrel} && $instqualtoolflag eq '0')
	{&SASHFADD_set_release_vars('94','MF_94_default');}
elsif(!$config{sasrel})
	{&SASHFADD_set_release_vars('xx','instqualtool');}

$output{log} .= $nullskip;
$output{log} .= $suppressed_hfids;
if($valid_product_count == 0)
	{
	$ERROR = 1;
	$output{log} .= ">> %%% ERROR: No valid SAS Product data found in DeploymentRegistry.txt.\n";
	}
return($hostlist);
}


################################################################################################################
### SASHFADD_load_SAS_HFADD_data										
### load the SAS_HFADD_data.xml data which was downloaded from the the hot fix site.				
###
sub SASHFADD_load_SAS_HFADD_data
{
my $hostlist = shift;

my @hostarray;
my $hfdatafile = "SAS$config{sasrel}_HFADD_data.xml";
if(open(hfdatafile, "$hfdatafile"))
	{$output{log} .= ">> $hfdatafile open\n";}
else
	{
	$ERROR = 1;
	$OPENDATAFILEERROR = 1;
	$output{log} .= ">> %%% ERROR: Unable to open $hfdatafile\n";
	}

$output{log} .= ">> Loading available SAS hot fix data\n";

my $line = <hfdatafile>;
chomp($line);
$line =~ s/\<SASHotFixDLM //;
$line =~ s/\>//;
my @linearray = split(/\"\s+/, $line);
my $ver = $linearray[0];
$ver =~ s/ver=\"//;
my $tstamp = $linearray[1];
$tstamp =~ s/tstamp=\"//;
my $tm = $linearray[2];
$tm =~ s/tm=\"//;
$tool{xml_version} = $ver;
$tool{xml_tstamp} = $tstamp;
$tool{xml_testmode} = $tm;

my $keyprocessed;
$line = <hfdatafile>;
while(!eof(hfdatafile))
	{
	if($line =~ /^\<hotfix/)
		{
		chomp($line);
		$line =~ s/\<hotfix //;
		$line =~ s/\/\>//;
		
		my @linearray = split(/\"\s+/, $line);
		my $hfid = $linearray[0];
		$hfid =~ s/id=\"//;
		my $host = $linearray[1];
		$host =~ s/host=\"//;
		my $primarykey = "${hfid}_${host}";
		
		foreach my $element(@linearray)
			{
			my @splitA = split(/=\"/, $element);
			my $elementkey = $splitA[0];
			my $elementvalue = $splitA[1];
			$hfdata{$primarykey}{$elementkey} = $elementvalue;
			
			if($elementkey eq 'xurl')
				{
				my @splitB = split(/\,/, $elementvalue);
				$hfdata{$primarykey}{pageurlcode} = $splitB[0];
				$hfdata{$primarykey}{dlurlcode} = $splitB[1];
				$hfdata{$primarykey}{idocurlcode} = $splitB[2];
				}
			} 

		my $crossrefkey = "$hfdata{$primarykey}{host}~$hfdata{$primarykey}{tbyte}~$hfdata{$primarykey}{prod_rel}~$hfdata{$primarykey}{prod_maint}";
		$hfdata_ref{$crossrefkey} .= " $primarykey ";
		
		if($reg_error{incomplete_list} =~ / $crossrefkey / && $keyprocessed !~ / $crossrefkey /)
			{
			$output{log} .= $reg_error{$crossrefkey};
			$keyprocessed .= " $crossrefkey ";
			}
		}
	elsif($line =~ /^\<nls/)
		{
		chomp($line);
		my @splitarray = split(/\"/, $line);
		my $key = $splitarray[1];
		my $value = $splitarray[3];
		push(@NLS2BYTE, $key);
		$nls{$key} = $value;
		}
	elsif($line =~ /^\<hosts/)
		{
		chomp($line);
		my @splitarray = split(/\"/, $line);
		my $hostname = $splitarray[1];
		my $hostgroup = $splitarray[3];
		my $hostofficial = $splitarray[5];
		$host{group}{$hostname} = $hostgroup;
		$host{official}{$hostname} = $hostofficial;
		push(@hostarray, $hostname);
		}
	elsif($line =~ /^\<noreport/)
		{
		chomp($line);
		my @splitarray = split(/\"/, $line);
		my $host_nr = $splitarray[1];
		my $ip = $splitarray[3];	# if present
		my $nr = $splitarray[5];	# no report
		if($host_nr eq 'all') 
			{
			foreach my $phost(@hostarray)
				{
				my $nrkey = "$phost~$nr";
				my $ipval = "$phost~$ip";
				$noreport{$nrkey}=$ipval;
				}
			}
		else
			{
			my $nrkey = "$host_nr~$nr";
			my $ipval = "$host_nr~$ip";
			$noreport{$nrkey}=$ipval;
			}
		}
	elsif($line =~ /^\<urls/)
		{
		chomp($line);
		my @splitarray = split(/\"/, $line);
		my $key = $splitarray[1];
		my $value = $splitarray[3];
		$urls{$key} = $value;
		}
	elsif($line =~ /^\<ftpx/)
		{
		chomp($line);
		my @splitarray = split(/\"/, $line);
		my $key = $splitarray[1];
		my $value = $splitarray[3];
		$ftpx{$key} = $value;
		}
	elsif($line =~ /^\<announce/)
		{
		chomp($line);
		my @splitarray = split(/\"/, $line);
		my $key = $splitarray[1];
		my $value = $splitarray[3];
		$announce{$key} = $value;
		$announce{$key} =~ s/\&quot\;/\"/g;
		$announce{$key} =~ s/\&lt\;/\</g;
		$announce{$key} =~ s/\&gt\;/\>/g;
		}
	$line = <hfdatafile>;
	}

foreach my $host(@hostarray)
	{
	if($hostlist =~ /$host\,/ && $host{group}{$host} ne 'indb')
		{
		$HOSTGROUP = "$host{group}{$host}";
		$output{log} .= ">> [$host] defines HOSTGROUP as \"$HOSTGROUP\"\n";
		}
	}
#DEBUG foreach my $debugkey(sort keys %hfdata_ref) {$output{log} .= "$debugkey:$hfdata_ref{$debugkey}\n";}
}


################################################################################################################
### Compare Deployment Registry data with available hot fix data and determine installed products that have	
### available hot fixes												
###
sub SASHFADD_compare_01
{
my $dl_key_used_list;
my $noreportloglist;

$output{log} .= ">> PRODUCTS IN THE DEPLOYMENT REGISTRY THAT HAVE HOT FIXES AVAILABLE FOR DOWNLOAD:\n";
foreach my $key(sort keys %reg_ref)   # $key = $host~$product~$prodversion~$maintenance
	{
	my $noreportflag = 0;

	if($noreport{$key})
		{
		my $this_ip = $noreport{$key};
		if($regProduct{$this_ip})
			{
			$noreportflag = 1;
			$noreportloglist .= " !** $regDisplayName{$key} $regVersion{$key}_M$regMaintenance{$key} ($key) skipped due to presence of ";
			$noreportloglist .= "$regDisplayName{$this_ip} $regVersion{$this_ip}_M$regMaintenance{$this_ip} ($this_ip)\n";
			}
		}
	
	if($hfdata_ref{$key} && $noreportflag eq '0')
		{
		$output{log} .= " *** $regDisplayName{$key} $regVersion{$key}_M$regMaintenance{$key} ($key)\n";
		$output{log} .= "     Available Hot Fixes: $hfdata_ref{$key}\n";
		$output{log} .= "     Installed Hot Fixes:    $reg_ref{$key}\n";
		
		my @comparearray = split(/\s+/, $hfdata_ref{$key});
		foreach my $hfid(@comparearray)
			{
			if($hfid && $reg_ref{$key} !~ / $hfid / && $SUPPRESSEDHFIDS !~ / $hfid /i)
				{
				$dl_hfids{$key} .= " $hfid ";					
				if($dl_key_used_list !~ / $key /)
					{
					push(@DL_KEYS, $key);
					$dl_key_used_list .= " $key ";
					}
				}
			elsif($hfid && $SUPPRESSEDHFIDS =~ / $hfid /i)
				{$output{log} .= "     Suppressed Hot Fix:   $hfid\n";}
			}
		}
	}
$output{log} .= $noreportloglist;
}

#														
#														
#	Analyzing Available Hot Fixes										
#														
#														

################################################################################################################
### Process each available hot fix										
###
sub SASHFADD_hot_fix_process_01
{
$output{log} .= ">> Hot Fixes to Process:\n";

my $thiscontainerprocessed;
foreach my $key(@DL_KEYS)  # host ~ 12byte
	{
	my @lochfidhstarray = split(/\s+/, $dl_hfids{$key});
	foreach my $hfidhst(@lochfidhstarray)
		{
		if($hfidhst)
			{
			my @splitA = split(/_/, $hfidhst);
			my $hfid = $splitA[0];
			my $hst = $splitA[1];
			if($hfdata{$hfidhst}{contype} =~ /2|3/)
				{
				my @incontainerarray;
				if($hfdata{$hfidhst}{incontainer} =~ /\:/) # in more than one container
					{@incontainerarray = split(/\:/, $hfdata{$hfidhst}{incontainer});}
				else
					{push(@incontainerarray, $hfdata{$hfidhst}{incontainer});}
				
				foreach my $thiscontainer(@incontainerarray)
					{
					
					my $thisconkey = "${thiscontainer}_$hst";
					my $contbyte = $hfdata{$thisconkey}{tbyte};

					if($thiscontainerprocessed !~ / $thisconkey /)
						{
						&SASHFADD_hot_fix_report_process_product_row($thisconkey);
						&SASHFADD_hot_fix_report_process_hfid_row($thisconkey, $contbyte);
						$thiscontainerprocessed .= "  $thisconkey  ";
						}				
					$output{log} .= "    $hfidhst for $key (container: $thisconkey [$contbyte])\n";
					}
				}
			else
				{
				if($config{english_only} eq '1' && $hfdata{$hfidhst}{langs} !~ /EN/)
					{$output{log} .= "    -ENGLISH_ONLY option suppresses processing of $hfidhst [$key] [$hfdata{$hfidhst}{langs}]\n";}
				else
					{
					&SASHFADD_hot_fix_report_process_product_row($hfidhst);
					&SASHFADD_hot_fix_report_process_hfid_row($hfidhst, $key);
					$output{log} .= "    $hfidhst for $key\n";
					}
				}
			}
		}
	}
}


################################################################################################################
### Generate a PRODUCT row for the final report									
###
sub SASHFADD_hot_fix_report_process_product_row
{
my $hfidhst = shift;

my $printprodmaint;
if($hfdata{$hfidhst}{prod_maint} > 0)
	{$printprodmaint = "_M$hfdata{$hfidhst}{prod_maint}";}

$hfdata{$hfidhst}{product_row} .= "<tr><td colspan=\"$RCOLSPAN\">&nbsp;</tr>\n";
$hfdata{$hfidhst}{product_row} .= "<tr><td colspan=\"$RCOLSPAN\" class=\"left\"><b>$hfdata{$hfidhst}{product} $hfdata{$hfidhst}{prod_rel}$printprodmaint</b> for <b>$host{official}{$hfdata{$hfidhst}{host}}</b></tr>\n";
$hfdata{$hfidhst}{product_row} .= "<tr><td class=\"left\">Hot Fix";
$hfdata{$hfidhst}{product_row} .= "<td class=\"left\">Released";
$hfdata{$hfidhst}{product_row} .= "<td class=\"left\">&nbsp;";
$hfdata{$hfidhst}{product_row} .= "<td class=\"left\">&nbsp;";
$hfdata{$hfidhst}{product_row} .= "<td class=\"left\">&nbsp;";
$hfdata{$hfidhst}{product_row} .= "</tr>\n";
}


################################################################################################################
### Generate a Hot Fix row for the final report									
###
sub SASHFADD_hot_fix_report_process_hfid_row
{
my $hfidhst = shift;
my $tbyte = shift;
my $outputrow;

my $supdlpgecmts;
if($hfdata{$hfidhst}{dlpgecmts} eq '1')
	{
	$supdlpgecmts = " [ <a href=\"#skey\">1</a> ]";
	$USEDCOMMENTS .= " dlpgecmts ";
	}
my $supcustomdoc;
if($hfdata{$hfidhst}{customdoc} eq '1')
	{
	$supcustomdoc = " [<a href=\"#skey\"><span class=\"yellowbg\">&nbsp;D&nbsp; </span></a>]";
	$USEDCOMMENTS .= " customdoc ";
	}
my $supnomit;
if($hfdata{$hfidhst}{nomit} eq '1')
	{
	$supnomit = " [ <a href=\"#skey\">2</a> ]";
	$USEDCOMMENTS .= " nomit ";
	}
my $supnodownload;
if($hfdata{$hfidhst}{nodownload} eq '1')
	{
	$supnodownload = " [ <a href=\"#skey\">3</a> ]";
	$USEDCOMMENTS .= " nodownload ";
	}
my $supiscontainer;
if($hfdata{$hfidhst}{contype} eq '1')
	{
	$supiscontainer = " [ <a href=\"#skey\">C</a> ]";
	$USEDCOMMENTS .= " iscontainer ";
	}
my $supalert;
if($hfdata{$hfidhst}{alert} eq '1')
	{
	$supalert = " [ <a href=\"#skey\"><span class=\"redbold\">A</span></a> ]";
	$USEDCOMMENTS .= " alert ";
	}
my $supsecurity;
if($hfdata{$hfidhst}{s} eq '1')
	{
	$supsecurity = " [ <a href=\"#skey\"><span class=\"security\">S</span></a> ]";
	$USEDCOMMENTS .= " security ";
	}

my $downloadcell = "   <td class=\"left\"><a href=\"$urls{u2}$hfdata{$hfidhst}{dlurl}\">Download</a>$supnomit";
if($hfdata{$hfidhst}{nodownload} eq '1')
	{$downloadcell = "   <td class=\"left\">&nbsp;";}

if($hfdata{$hfidhst}{sn} =~ /\d+/)
	{
	my $isnlinks;
	my @isnarray = split(/,/, $hfdata{$hfidhst}{sn});
	foreach my $isn(@isnarray)
		{$isnlinks .= " <a href=\"http://support.sas.com/kb/$isn.html\" target=\"$isn\">$isn</a> ";}
	$downloadcell .= " &nbsp; &nbsp; See: $isnlinks ";
	}
$downloadcell .="\n";

my $PrintReleaseDate = $hfdata{$hfidhst}{release_date};
if($hfdata{$hfidhst}{week} =~ /\d/ && $hfdata{$hfidhst}{week} <= $config{highlight_week})
	{
	my $addS;
	if($hfdata{$hfidhst}{week} > 1){$addS = "s";}
	$PrintReleaseDate = "<span class=\"bluebg\">$PrintReleaseDate < $hfdata{$hfidhst}{week} week$addS</span>";
	}

$hfdata{$hfidhst}{hfid_row} .= "<tr>\n   <td class=\"left\">$hfdata{$hfidhst}{id}$supnodownload$supiscontainer\n";
$hfdata{$hfidhst}{hfid_row} .= "   <td class=\"left\">$PrintReleaseDate\n";
$hfdata{$hfidhst}{hfid_row} .= "   <td class=\"left\"><a href=\"$urls{u2}$hfdata{$hfidhst}{pageurl}\" target=\"p$hfidhst\">Issue(s) Addressed</a>$supalert$supdlpgecmts$supsecurity\n";
$hfdata{$hfidhst}{hfid_row} .= "   <td class=\"left\"><a href=\"$urls{u2}$hfdata{$hfidhst}{idocurl}\" target=\"d$hfidhst\">Documentation</a>$supcustomdoc\n";
$hfdata{$hfidhst}{hfid_row} .= $downloadcell;
$hfdata{$hfidhst}{hfid_row} .= "</tr>\n";

if(($hfdata{$hfidhst}{nodownload} eq '1' || $hfdata{$hfidhst}{nomit} eq '1') && $hfdata{$hfidhst}{langs} !~ /EN/)
	{push(@NONENGLISH, $hfidhst);}
elsif($hfdata{$hfidhst}{nodownload} eq '1' || $hfdata{$hfidhst}{nomit} eq '1')
	{push(@NOMITARRAY, $hfidhst);}
elsif($hfdata{$hfidhst}{langs} !~ /EN/)
	{push(@NONENGLISH, $hfidhst);}
else
	{
	push(@HFIDHSTARRAY, $hfidhst);
	$HFIDHSTLIST .= " $hfidhst ";
	if($hfdata{$hfidhst}{alert} eq '1')
		{$AT_LEAST_ONE_ALERT_FLAG = 1;}
	}

my $checksumline = "$hfdata{$hfidhst}{dlname}:$hfdata{$hfidhst}{md5}\n";
push(@MD5ARRAY, $checksumline);
if($hfdata{$hfidhst}{alert} eq '1')
	{push(@MD5ARRAYALERT, $checksumline);}

return $outputrow;
}


#														
#														
#	XML DATA FILE Script Generation										
#														
#														

################################################################################################################
### Generate the SAS*_HFADD_data.xml download script								
###
sub SASHFADD_HFADD_data_xml_download_script_generate_and_run
{
my $rcftp;

if($PLATFORM eq 'win')
	{
	my $scriptoutbatfile;
	if($config{sftp_secure_scripting} eq '1')
		{$scriptoutbatfile = &SASHFADD_xml_data_download_WIN_SECURE_SFTP;}
	elsif($config{basic_ftp_scripting} eq '1')
		{$scriptoutbatfile = &SASHFADD_xml_data_download_WIN_FTP;}
	else
		{$scriptoutbatfile = &SASHFADD_xml_data_download_WIN_POWERSHELL;}

	# RUN .bat
	my $syscommand = "$scriptoutbatfile";
	$rcftp = system($syscommand);
	}
elsif($PLATFORM eq 'unix')
	{
	my $scriptoutfilesh;
	if($config{sftp_secure_scripting} eq '1')
		{$scriptoutfilesh = &SASHFADD_xml_data_download_UNIX_SECURE_SFTP;}
	elsif($config{basic_ftp_scripting} eq '1')
		{$scriptoutfilesh = &SASHFADD_xml_data_download_UNIX_FTP;}
	else
		{$scriptoutfilesh = &SASHFADD_xml_data_download_UNIX_CURL;}

	# RUN ftp .sh
	my $syscommand = "./$scriptoutfilesh";
	$rcftp = system($syscommand);		
	}
}


################################################################################################################
###														
### WIN - XML Download - SECURE SFTP										
###														
sub SASHFADD_xml_data_download_WIN_SECURE_SFTP
{
my $scriptoutbatfile;
my $xmlscriptbat;
my $scriptouttxtfile;
my $xmlscripttxt;

# WIN - Secure SFTP .txt file
$scriptouttxtfile .= "SAS$config{sasrel}_HFADD_data_sftp_download_script.txt";

$xmlscripttxt .= "cd /hotfix/HF2/util01/SASHotFixDLM/data\n";
$xmlscripttxt .= "get SAS$config{sasrel}_HFADD_data.xml\n";
$xmlscripttxt .= "quit\n$EOF";

&SASHFADD_win_flat_file_writer($scriptouttxtfile, $xmlscripttxt);

# WIN - Secure SFTP .bat file
$scriptoutbatfile = "SAS$config{sasrel}_HFADD_data_sftp_download.bat";
$xmlscriptbat .= "psftp.exe hfclient\@sftp1.sas.com -bc -be -b $scriptouttxtfile\n";

&SASHFADD_win_flat_file_writer($scriptoutbatfile, $xmlscriptbat);

$output{log} .= ">> Writing Windows SFTP system compliant $scriptouttxtfile\n";
$output{log} .= ">> Writing Windows SFTP system compliant $scriptoutbatfile\n";

return($scriptoutbatfile);
}


################################################################################################################
###														
### WIN - XML Download - Regular FTP										
###														
sub SASHFADD_xml_data_download_WIN_FTP
{
my $xmlscriptbat;
my $scriptouttxtfile;
my $xmlscripttxt;

# WIN - Regular FTP .txt file
$scriptouttxtfile = "SAS$config{sasrel}_HFADD_data_ftp_download_script.txt";
$xmlscripttxt .= &SASHFADD_generate_regular_FTP_script_header;
$xmlscripttxt .= "binary\n";
$xmlscripttxt .= "get techsup/download/hotfix/HF2/util01/SASHotFixDLM/data/SAS$config{sasrel}_HFADD_data.xml\n";
$xmlscripttxt .= "quit\n$EOF";

&SASHFADD_win_flat_file_writer($scriptouttxtfile, $xmlscripttxt);

# WIN - Regular FTP .bat file
my $scriptoutbatfile = "SAS$config{sasrel}_HFADD_data_ftp_download.bat";
my $xmlscriptbat .= "ftp -s:$scriptouttxtfile";

&SASHFADD_win_flat_file_writer($scriptoutbatfile, $xmlscriptbat);

$output{log} .= ">> Writing Windows system compliant $scriptouttxtfile\n";
$output{log} .= ">> Writing Windows system compliant $scriptoutbatfile  :  modified_script_header = $config{modified_script_header}\n";

return($scriptoutbatfile);
}

################################################################################################################
###														
### WIN - XML Download - POWERSHELL										
###														
sub SASHFADD_xml_data_download_WIN_POWERSHELL
{
my $xmlscriptbat;
my $scriptoutbatfile;
my $scriptouttxtfile;
my $xmlscripttxt;
my $notused;

$scriptoutbatfile = "SAS$config{sasrel}_HFADD_data_powershell_download.bat";

$xmlscriptbat .= $USER_SUPPLIED_SCRIPT_HEADER;
$xmlscriptbat .= "powershell -Command \"Invoke-WebRequest https://tshf.sas.com/techsup/download/hotfix/HF2/util01/SASHotFixDLM/data/SAS$config{sasrel}_HFADD_data.xml -OutFile SAS$config{sasrel}_HFADD_data.xml$USER_SUPPLIED_COMMAND_LINE_OPTIONS\"\n";

$output{log} .= ">> Writing Windows system compliant POWERSHELL $scriptoutbatfile\n";
&SASHFADD_win_flat_file_writer($scriptoutbatfile, $xmlscriptbat);

return($scriptoutbatfile);
}

################################################################################################################
###														
### UNIX - XML Download - SECURE SFTP										
###														
sub SASHFADD_xml_data_download_UNIX_SECURE_SFTP
{
my $scriptoutfiletxt;
my $xmlscriptsh;
my $scriptoutfilesh;
my $xmlscripttxt;

# UNIX - Secure SFTP .txt file
$scriptoutfiletxt = "SAS$config{sasrel}_HFADD_data_sftp_download.txt";

$xmlscripttxt  = "cd /hotfix/HF2/util01/SASHotFixDLM/data\n";
$xmlscripttxt .= "get SAS$config{sasrel}_HFADD_data.xml\n";
$xmlscripttxt .= "quit\n$EOF";

&SASHFADD_unix_flat_file_writer($scriptoutfiletxt, $xmlscripttxt);

# UNIX - Secure SFTP .sh file
$scriptoutfilesh = "SAS$config{sasrel}_HFADD_data_sftp_download.sh";

$xmlscriptsh = "#!/bin/sh\n";
$xmlscriptsh .= "sftp -o \"batchmode no\" -b $scriptoutfiletxt hfclient\@sftp1.sas.com\n\n";

&SASHFADD_unix_flat_file_writer($scriptoutfilesh, $xmlscriptsh);

$output{log} .= ">> Writing UNIX system compliant $scriptoutfilesh\n";
$output{log} .= ">> Writing UNIX system compliant $scriptoutfiletxt\n";

return($scriptoutfilesh);
}

################################################################################################################
###														
### UNIX - XML Download - Regular FTP										
###														
sub SASHFADD_xml_data_download_UNIX_FTP
{
my $scriptoutfilesh;
my $xmlscriptsh;

$scriptoutfilesh = "SAS$config{sasrel}_HFADD_data_ftp_download.sh";

# UNIX - Regular FTP .sh file
$xmlscriptsh .= &SASHFADD_generate_regular_FTP_script_header;
$xmlscriptsh .= "binary\n";
$xmlscriptsh .= "cd techsup/download/hotfix/HF2/util01/SASHotFixDLM/data\n";
$xmlscriptsh .= "get SAS$config{sasrel}_HFADD_data.xml\n";
$xmlscriptsh .= "quit\n$EOF";

&SASHFADD_unix_flat_file_writer($scriptoutfilesh, $xmlscriptsh);

$output{log} .= ">> Writing UNIX system compliant $scriptoutfilesh  :  modified_script_header = $config{modified_script_header}\n";

return($scriptoutfilesh);
}

################################################################################################################
###														
### UNIX - XML Download - CURL										
###														
sub SASHFADD_xml_data_download_UNIX_CURL
{
my $scriptoutfilesh;
my $xmlscriptsh;

$scriptoutfilesh = "SAS$config{sasrel}_HFADD_data_ftp_download.sh";

# UNIX - CURL .sh file
$xmlscriptsh .= $USER_SUPPLIED_SCRIPT_HEADER;;
$xmlscriptsh .= "curl https://tshf.sas.com/techsup/download/hotfix/HF2/util01/SASHotFixDLM/data/SAS$config{sasrel}_HFADD_data.xml -o SAS$config{sasrel}_HFADD_data.xml$USER_SUPPLIED_COMMAND_LINE_OPTIONS";

&SASHFADD_unix_flat_file_writer($scriptoutfilesh, $xmlscriptsh);

$output{log} .= ">> Writing UNIX system compliant CURL $scriptoutfilesh\n";
&SASHFADD_unix_flat_file_writer($scriptoutfilesh, $xmlscriptsh);

return($scriptoutfilesh);
}


#														
#														
#	HOT FIX DOWNLOAD Script Generation									
#														
#														

################################################################################################################
### Generate the Hot Fix Download Script									
###
sub SASHFADD_hot_fix_download_script_gen
{
if($PLATFORM eq 'win')
	{
	if($config{sftp_secure_scripting} eq '1') 
		{&SASHFADD_HOT_FIX_download_WIN_SECURE_SFTP;}
	elsif($config{basic_ftp_scripting} eq '1') 
		{&SASHFADD_HOT_FIX_download_WIN_FTP;}
	else
		{&SASHFADD_HOT_FIX_download_WIN_POWERSHELL;}
	}
elsif($PLATFORM eq 'unix')
	{
	if($config{sftp_secure_scripting} eq '1')
		{&SASHFADD_HOT_FIX_download_UNIX_SECURE_SFTP;}
	elsif($config{basic_ftp_scripting} eq '1')
		{&SASHFADD_HOT_FIX_download_UNIX_FTP;}
	else
		{&SASHFADD_HOT_FIX_download_UNIX_CURL;}
	}
}


################################################################################################################
###														
### WIN - HOT FIX Download - SECURE SFTP									
###														
sub SASHFADD_HOT_FIX_download_WIN_SECURE_SFTP
{
my $dlcall;
my $dlcallALERT;
my $dlscripttxt;
my $dlscripttxtALERT;

$output{log} .= ">> Generating Windows system compliant SFTP download script(s) for hot fixes\n";
$dlcall = "psftp.exe hfclient\@$ftpx{s1} -bc -be -b $filename{dlmftp}";
$dlcallALERT = "psftp.exe hfclient\@$ftpx{s1} -bc -be -b $filename{dlmftpALERT}";

$dlscripttxt .= &SASHFADD_hot_fix_dl_lines('all');
$dlscripttxtALERT .= &SASHFADD_hot_fix_dl_lines('alert');

$dlscripttxt .= "quit\n$EOF";
$dlscripttxtALERT .= "quit\n$EOF";

if($config{alert_only_scripting} ne '1')
	{
	&SASHFADD_win_flat_file_writer($filehandle{dlmftpbat}, $dlcall);
	&SASHFADD_win_flat_file_writer($filehandle{dlmftp}, $dlscripttxt);
	}
if($AT_LEAST_ONE_ALERT_FLAG eq '1' && $config{all_eligible_scripting} ne '1')
	{
	&SASHFADD_win_flat_file_writer($filehandle{dlmftpbatALERT}, $dlcallALERT);
	&SASHFADD_win_flat_file_writer($filehandle{dlmftpALERT}, $dlscripttxtALERT);
	&SASHFADD_win_flat_file_writer($filehandle{alert_readme_downloadtools}, $ALERT_README);
	}
}

################################################################################################################
###														
### WIN - HOT FIX Download - Regular FTP									
###														
sub SASHFADD_HOT_FIX_download_WIN_FTP
{
my $dlcall;
my $dlcallALERT;
my $dlscripttxt;
my $dlscripttxtALERT;

$output{log} .= ">> Generating Windows system compliant FTP download script(s) for hot fixes\n";
$dlcall = "ftp -s:$filename{dlmftp}";
$dlcallALERT = "ftp -s:$filename{dlmftpALERT}";

$dlscripttxt .= &SASHFADD_generate_regular_FTP_script_header;
$dlscripttxt .= "binary\n";
$dlscripttxtALERT = $dlscripttxt;	

$dlscripttxt .= &SASHFADD_hot_fix_dl_lines('all');
$dlscripttxtALERT .= &SASHFADD_hot_fix_dl_lines('alert');

$dlscripttxt .= "quit\n$EOF";
$dlscripttxtALERT .= "quit\n$EOF";

if($config{alert_only_scripting} ne '1')
	{
	&SASHFADD_win_flat_file_writer($filehandle{dlmftpbat}, $dlcall);
	&SASHFADD_win_flat_file_writer($filehandle{dlmftp}, $dlscripttxt);
	}
if($AT_LEAST_ONE_ALERT_FLAG eq '1' && $config{all_eligible_scripting} ne '1')
	{
	&SASHFADD_win_flat_file_writer($filehandle{dlmftpbatALERT}, $dlcallALERT);
	&SASHFADD_win_flat_file_writer($filehandle{dlmftpALERT}, $dlscripttxtALERT);
	&SASHFADD_win_flat_file_writer($filehandle{alert_readme_downloadtools}, $ALERT_README);
	}
}

################################################################################################################
###														
### WIN - HOT FIX Download - POWERSHELL										
###														
sub SASHFADD_HOT_FIX_download_WIN_POWERSHELL
{
my $dlcall;
my $dlcallALERT;
my $dlscripttxt;
my $dlscripttxtALERT;

$output{log} .= ">> Generating Windows system compliant Powershell download script(s) for hot fixes\n";

$dlscripttxt .= $USER_SUPPLIED_SCRIPT_HEADER;
$dlscripttxtALERT .= $USER_SUPPLIED_SCRIPT_HEADER;

$dlscripttxt .= &SASHFADD_hot_fix_dl_lines('all');
$dlscripttxtALERT .= &SASHFADD_hot_fix_dl_lines('alert');

$dlscripttxt .= "$EOF";
$dlscripttxtALERT .= "$EOF";

if($config{alert_only_scripting} ne '1')
	{
	&SASHFADD_win_flat_file_writer($filehandle{dlmpower}, $dlscripttxt);
	}
if($AT_LEAST_ONE_ALERT_FLAG eq '1' && $config{all_eligible_scripting} ne '1')
	{
	&SASHFADD_win_flat_file_writer($filehandle{dlmpowerALERT}, $dlscripttxtALERT);
	&SASHFADD_win_flat_file_writer($filehandle{alert_readme_downloadtools}, $ALERT_README);
	}
}


################################################################################################################
###														
### UNIX - HOT FIX Download - SECURE SFTP									
###														
sub SASHFADD_HOT_FIX_download_UNIX_SECURE_SFTP
{
my $dlcall;
my $dlcallALERT;
my $dlscripttxt;
my $dlscripttxtALERT;

$output{log} .= ">> Generating UNIX system compliant SFTP download script(s) for hot fixes\n";
$dlcall = "sftp -o \"batchmode no\" -b $filename{sftptxt}  hfclient\@$ftpx{s1}";
$dlcallALERT = "sftp -o \"batchmode no\" -b $filename{sftpALERTtxt}  hfclient\@$ftpx{s1}";

$dlscripttxt .= &SASHFADD_hot_fix_dl_lines('all');
$dlscripttxtALERT .= &SASHFADD_hot_fix_dl_lines('alert');

$dlscripttxt .= "quit\n$EOF";
$dlscripttxtALERT .= "quit\n$EOF";

if($config{alert_only_scripting} ne '1')
	{
	&SASHFADD_unix_flat_file_writer($filehandle{dlmftp}, $dlcall);
	&SASHFADD_unix_flat_file_writer($filehandle{sftptxt}, $dlscripttxt);
	}
if($AT_LEAST_ONE_ALERT_FLAG eq '1' && $config{all_eligible_scripting} ne '1')
	{
	&SASHFADD_unix_flat_file_writer($filehandle{dlmftpALERT}, $dlcallALERT);
	&SASHFADD_unix_flat_file_writer($filehandle{sftpALERTtxt}, $dlscripttxtALERT);
	&SASHFADD_unix_flat_file_writer($filehandle{alert_readme_downloadtools}, $ALERT_README);
	}
}

################################################################################################################
###														
### UNIX - HOT FIX Download - Regular FTP									
###														
sub SASHFADD_HOT_FIX_download_UNIX_FTP
{
my $dlcall;
my $dlcallALERT;
my $dlscripttxt;
my $dlscripttxtALERT;

$output{log} .= ">> Generating UNIX system compliant FTP download script(s) for hot fixes\n";
$dlcall = "ftp -s:$filename{dlmftp}";
$dlcallALERT = "ftp -s:$filename{dlmftpALERT}";

$dlscripttxt .= &SASHFADD_generate_regular_FTP_script_header;
$dlscripttxt .= "binary\n";
$dlscripttxtALERT = $dlscripttxt;

$dlscripttxt .= &SASHFADD_hot_fix_dl_lines('all');
$dlscripttxtALERT .= &SASHFADD_hot_fix_dl_lines('alert');

$dlscripttxt .= "quit\n$EOF";
$dlscripttxtALERT .= "quit\n$EOF";

if($config{alert_only_scripting} ne '1')
	{&SASHFADD_unix_flat_file_writer($filehandle{dlmftp}, $dlscripttxt);}
if($AT_LEAST_ONE_ALERT_FLAG eq '1' && ($config{all_eligible_scripting} ne '1'))
	{
	&SASHFADD_unix_flat_file_writer($filehandle{dlmftpALERT}, $dlscripttxtALERT);
	&SASHFADD_unix_flat_file_writer($filehandle{alert_readme_downloadtools}, $ALERT_README);
	}
}

################################################################################################################
###														
### UNIX - HOT FIX Download - CURL										
###														
sub SASHFADD_HOT_FIX_download_UNIX_CURL
{
my $dlscripttxt;
my $dlscripttxtALERT;

$output{log} .= ">> Generating UNIX system compliant CURL download script(s) for hot fixes\n";

$dlscripttxt .= $USER_SUPPLIED_SCRIPT_HEADER;
$dlscripttxtALERT .= $USER_SUPPLIED_SCRIPT_HEADER;

$dlscripttxt .= &SASHFADD_hot_fix_dl_lines('all');
$dlscripttxtALERT .= &SASHFADD_hot_fix_dl_lines('alert');

if($config{alert_only_scripting} ne '1')
	{
	&SASHFADD_unix_flat_file_writer($filehandle{dlmcurl}, $dlscripttxt);
	}
if($AT_LEAST_ONE_ALERT_FLAG eq '1' && $config{all_eligible_scripting} ne '1')
	{
	&SASHFADD_unix_flat_file_writer($filehandle{dlmcurlALERT}, $dlscripttxtALERT);
	&SASHFADD_unix_flat_file_writer($filehandle{alert_readme_downloadtools}, $ALERT_README);
	}
}

################################################################################################################
###
###
sub SASHFADD_generate_regular_FTP_script_header
{
my $script_header;

if($config{modified_script_header} eq '0')
	{
	if($PLATFORM eq 'win')
		{
		$script_header .= "open ftp.sas.com\n";
		$script_header .= "anonymous\n";
		$script_header .= "SASHFADD\n";
		}
	elsif($PLATFORM eq 'unix')
		{
		$script_header .= "#!/bin/sh\n";
		$script_header .= "FTPHOST=ftp.sas.com\n";
		$script_header .= "FTPUSER=anonymous\n";
		$script_header .= "FTPPW=SASHFADD\n";
		$script_header .= "ftp -n \$FTPHOST <<-EOF\n";
		$script_header .= "user \$FTPUSER \$FTPPW\n";
		}
	}
else
	{$script_header = $USER_SUPPLIED_SCRIPT_HEADER;}
	
return($script_header);
}

################################################################################################################
###
###
sub SASHFADD_load_modified_script_header
{
my $in = "modified_script_header.txt";

if(open(in, "$in"))
	{$output{log} .= ">> $in open\n";}
else
	{
	$ERROR = 1;
	$output{log} .= ">> %%% ERROR: Unable to open \"$in\"\n";
	print "\n\n>>> SASHFADD ERROR: Unable to open \"$in\".\nThis error must be corrected or you must enable\ndefault script headers by \"commenting\" the SASHFADD.cfg line\n-USE_MODIFIED_SCRIPT_HEADER\n\n";
	if($PLATFORM eq 'win')
		{
		print "Press \"Enter\" to end this program.";
		my $exitcode = <>;
		}
	exit(0);
	}

$USER_SUPPLIED_SCRIPT_HEADER = do { local $/; <in> };

$output{log} .= ">> Reading $in:\n+++\n$USER_SUPPLIED_SCRIPT_HEADER\n+++\n";

}

################################################################################################################
###
###
sub SASHFADD_load_command_line_options
{
my $in = "additional_command_line_options.txt";

if(open(in, "$in"))
	{$output{log} .= ">> $in open\n";}
else
	{
	$ERROR = 1;
	$output{log} .= ">> %%% ERROR: Unable to open \"$in\"\n";
	print "\n\n>>> SASHFADD ERROR: Unable to open \"$in\".\nThis error must be corrected, or you must \"comment\" the SASHFADD.cfg line:\n-APPLY_ADDITIONAL_DOWNLOAD_COMMAND_OPTIONS\nby placing a # in front of the option\n\n";
	if($PLATFORM eq 'win')
		{
		print "Press \"Enter\" to end this program.";
		my $exitcode = <>;
		}
	exit(0);
	}

$USER_SUPPLIED_COMMAND_LINE_OPTIONS = " ";
$USER_SUPPLIED_COMMAND_LINE_OPTIONS .= do { local $/; <in> };

$output{log} .= ">> Reading $in:\n+++\n$USER_SUPPLIED_COMMAND_LINE_OPTIONS\n+++\n";

}

################################################################################################################
###
###
sub SASHFADD_hot_fix_dl_lines
{
my $hfarraytype = shift;
my @hfidarray = ();
my $dlscript;

if($hfarraytype eq 'all')
	{@hfidarray = @HFIDHSTARRAY;}
elsif($hfarraytype eq 'alert')
	{@hfidarray = @HFIDHSTALERTDEPARRAY;}

foreach my $hfid(@hfidarray)
	{
	my $getthis = "$urls{$hfdata{$hfid}{dlurlcode}}$hfdata{$hfid}{dlurl}";
	$getthis =~ s/http\:\/\/$ftpx{f1}\///;
	my $splithost = $hfdata{$hfid}{host};
	if($getthis =~ /\/prt\//)
		{$splithost = "prt";}			
	my @splitA = split(/$splithost\//, $getthis);
	my $getpath = "$splitA[0]$splithost";
	my $gethf = "$splitA[1]";

	if($config{basic_ftp_scripting} eq '1' || $config{sftp_secure_scripting} eq '1')
		{
		my $cdline = "cd /$getpath\n";
		if($config{sftp_secure_scripting} eq '1')
			{$cdline =~ s/\/techsup\/download//;}
		$dlscript .= $cdline;
		$dlscript .= "get $gethf ../$dirname{deploy}/$hfdata{$hfid}{dlname}\n";
		}
	else
		{
		if($PLATFORM eq 'win')
			{$dlscript .= "powershell -Command \"Invoke-WebRequest https://tshf.sas.com/$getpath/$gethf -OutFile ../$dirname{deploy}/$hfdata{$hfid}{dlname}$USER_SUPPLIED_COMMAND_LINE_OPTIONS\"\n";}
		elsif($PLATFORM eq 'unix')
			{$dlscript .= "curl https://tshf.sas.com/$getpath/$gethf -o ../$dirname{deploy}/$hfdata{$hfid}{dlname}$USER_SUPPLIED_COMMAND_LINE_OPTIONS\n";}
		}
	}

return($dlscript);
}

###############################################################################################################
###
###
sub SASHFADD_sdm_readme_gen
{

my $sdm_readme = 
"Do NOT extract the contents of any downloaded <hot_fix_id>.zip files!

The hot fixes will be applied using the SAS Deployment Manager and should not be unzipped in advance.
By default, the SAS Deployment Manager will search in the <SASHOME>$pslash{$PLATFORM}InstallMisc$pslash{$PLATFORM}HotFixes$pslash{$PLATFORM}New directory 
for hot fixes to be applied.

You can copy the downloaded hot fixes to that directory, or, when prompted by the SAS Deployment Manager, 
you can enter the path to the directory where the hot fixes were originally downloaded (the directory that
contains the README file you are viewing now).

See the SASHFADD Usage Guide for more information:
$USAGE_GUIDE_LINK

Prior to downloading and installing hot fixes, it is extremely important that you review the generated
\"SAS_Hot_Fix_Analysis_Report\".  Pay close attention to hot fixes with a 
[ D ] next to the \"Documentation\" link and follow all pre/post installation instructions contained
in the documentation.\n\n";

if($PLATFORM eq 'win')
	{&SASHFADD_win_flat_file_writer($filehandle{sas93_94_install_readme_deploytools}, $sdm_readme);}
else
	{&SASHFADD_unix_flat_file_writer($filehandle{sas93_94_install_readme_deploytools}, $sdm_readme);}
}


################################################################################################################
### Generate MD5 checksum file											
###
sub SASHFADD_md5_list_gen
{
my $printmd5;
my $printmd5ALERT;
foreach my $md5line(@MD5ARRAY)
	{$printmd5 .= "$md5line";}
foreach my $md5line(@MD5ARRAYALERT)
	{$printmd5ALERT .= "$md5line";}


if($PLATFORM eq 'win')
	{
	$output{log} .= ">> Printing MD5 Checksums for hot fixes\n";	
	if($config{alert_only_scripting} ne '1')
		{&SASHFADD_win_flat_file_writer($filehandle{md5}, $printmd5);}
	if($AT_LEAST_ONE_ALERT_FLAG eq '1' && ($config{all_eligible_scripting} ne '1'))
		{
		$output{log} .= ">> Printing MD5 Checksums for hot fixes [ALERT ONLY]\n";	
		&SASHFADD_win_flat_file_writer($filehandle{md5ALERT}, $printmd5ALERT);
		}
	}
elsif($PLATFORM eq 'unix')
	{
	$output{log} .= ">> Printing MD5 Checksums for hot fixes\n";	
	if($config{alert_only_scripting} ne '1')
		{&SASHFADD_unix_flat_file_writer($filehandle{md5}, $printmd5);}
	if($AT_LEAST_ONE_ALERT_FLAG eq '1' && ($config{all_eligible_scripting} ne '1'))
		{
		$output{log} .= ">> Printing MD5 Checksums for hot fixes [ALERT ONLY]\n";	
		&SASHFADD_unix_flat_file_writer($filehandle{md5ALERT}, $printmd5ALERT);
		}
	}
}

################################################################################################################
### UNIX Flat File Writer											
###
sub SASHFADD_unix_flat_file_writer
{
my $outfile = shift;
my $writecontent = shift;
if(open(outfile, ">$outfile"))
	{$output{log} .= ">> $outfile open\n";}
else
	{$output{log} .= ">> %%% ERROR: Unable to open $outfile\n";}
binmode outfile;
print outfile "$writecontent";
close(outfile);
if($PLATFORM eq 'unix')
	{
	my $syscommand = "chmod 755 $outfile";
	system("$syscommand");
	}
}

################################################################################################################
### WIN Flat File Writer											
###
sub SASHFADD_win_flat_file_writer
{
my $outfile = shift;
my $writecontent = shift;
if(open(outfile, ">$outfile"))
	{$output{log} .= ">> $outfile open\n";}
else
	{$output{log} .= ">> %%% ERROR: Unable to open $outfile\n";}
print outfile "$writecontent";
close(outfile);
}



#														
#														
#	Processing Output											
#														
#														

################################################################################################################
### Initialize the final report											
###
sub SASHFADD_initialize_report
{

my $xmldate = localtime($tool{xml_tstamp});
my $timediff = abs(int(($TSTAMP - $tool{xml_tstamp})/3600));
my $timdiffwarning;
my $printhour = "hour";
if($timediff ne '1')
	{$printhour .= "s";}
	
if ($timediff > 96)
	{
	$timdiffwarning = "<tr><td class=\"center yellowbg\" nowrap><span class=\"redbold\">Warning</span>: Hot Fix Data file (SAS$config{sasrel}_HFADD_data.xml) is not found or is more than 96 hours old.<br>\n";
	$timdiffwarning .= "Please see <a href=\"$USAGE_GUIDE_LINK\" target=\"SASHFADD_guide\">Usage Guide - Troubleshooting</a> for more information.</tr>";
	$output{log} .= ">> SAS$config{sasrel}_HFADD_data.xml is $timediff hours old.  Warning generated!\n";
	}
else
	{$output{log} .= ">> SAS$config{sasrel}_HFADD_data.xml is $timediff $printhour old.  Warnings start at 96 hours.\n";}

my $this_announcement;
if($announce{a1})
	{$this_announcement = "<tr><td class=\"center\" nowrap>$announce{a1}</tr>\n";}

$output{report_header} = &SASHFADD_load_common_style('HF_Report1');

$output{report_header} .= "$output{report_css}
<body>
<table>
<tr><td class=\"center\"><span class=\"h1\">SAS Hot Fix Analysis, Download and Deployment Tool</span></tr>
<tr><td class=\"center\"><span class=\"f1\">Analyzing a SAS $config{printsasrel} Installation</span></tr>
<tr><td class=\"center\" nowrap>SASHFADD Ver. $tool{print_version} Report Date: $CURTIME</tr>
<tr><td class=\"center\" nowrap>Using SAS $config{printsasrel} Hot Fix Data generated: $xmldate ($timediff $printhour old)</tr>
$timdiffwarning
<tr><td>&nbsp;</tr>
<tr><td class=\"center\" nowrap><a href=\"$USAGE_GUIDE_LINK\" target=\"SASHFADD_guide\">Usage Guide</a></tr>
<tr><td class=\"center\" nowrap>Output Directory: $filehandle{printoutputdir}</tr>
<tr><td>&nbsp;</tr>
$this_announcement
</table>\n<hr>\n";

if($USEDCOMMENTS)
	{
	$output{report_footer} .= "<p>&nbsp;<p>&nbsp;<p><span id=\"skey\"></span>\n";
	$output{report_footer} .= "<table cellpadding=\"4\"><tr><td class=\"left graybg h1\" colspan=\"2\">Citation Key:</tr>\n";
	foreach my $comment(@COMMENTARRAY)
		{
		if($USEDCOMMENTS =~ / $comment /)
			{
			my $key = "citation_$comment";
			my $printcitationkey = $comments{$key};
			if($comment eq 'alert')
				{$printcitationkey = "$printcitationkey";}
			if($comment eq 'security')
				{$printcitationkey = "$printcitationkey";}
			if($comment eq 'customdoc')
				{$printcitationkey = "<span class=\"yellowbg\">$printcitationkey</span>";}
			$output{report_footer} .= "<tr><td class=\"left\" valign=\"top\" nowrap width=\"25\">[ $printcitationkey ]<td class=\"left\">$comments{$comment}</tr>\n";
			$output{key_header} .= "[ $printcitationkey ] ";
			$output{citationcount}++;
			}
		}
	$output{report_footer} .= "</table>\n";
	}
if($config{report})
	{
	$output{report_footer} .= "<p>&nbsp;<p>&nbsp;<p><span id=\"opts\"></span>\n";
	$output{report_footer} .= "<table cellpadding=\"4\"><tr><td class=\"left graybg h1\">Options:</tr>\n";
	$output{report_footer} .= "<tr><td class=\"left\">SASHFADD was run with the following option(s) set in SASHFADD.cfg:</tr>\n";
	$output{report_footer} .= $config{report};	
	$output{report_footer} .= "</table>\n";
	}
}

################################################################################################################
### Load the common style 				 							
###
sub SASHFADD_load_common_style
{
my $report_type = shift;  # HF_Report1, HF_Manifest1

my $report1tableaddition;
my $title = "Installed Hot Fix Manifest - SASHFADD Ver. $tool{print_version}";
if($report_type eq 'HF_Report1')
	{
	$report1tableaddition = " margin:0px;padding:0px;width: 100%;";
	$title = "SAS Hot Fix Analysis and Download Tool - SASHFADD Ver. $tool{print_version}";
	}

my $common_style = "<!DOCTYPE html>
<html>\n<head>\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">
<title>$title</title>
<STYLE TYPE=\"text/css\" MEDIA=screen>
<!--
body		{margin:1px auto; padding: 0; font-family: \"arial\", arial; text-align: left; min-width: 800px; background-color: #ffffff; }
table		{font-family:\"arial\", arial; font-size:  10pt; font-weight: 500; background-color: #FFFFFF; margin:0px; padding:0px; width:100%;}
.left		{text-align: left;}
.center		{text-align: center;}
.graybg		{background-color: #dddddd;}
.yellowbg	{background-color: #ffff00;}
.bluebg		{background-color: #99ffff;}
.h1		{font-family: \"arial\", arial; font-size:  16pt; font-weight: 500;}
.f1		{font-family: \"arial\", arial; font-size:  10pt; font-weight: 700;}
.c1		{font-family: \"arial\", arial; font-size:  10pt; font-weight: 700; background-color: #fffbde;}
.f2		{font-family: \"arial\", arial; font-size:  13pt; font-weight: 600;}
.redbold	{font-family: \"arial\", arial; font-size:  10pt; font-weight: 700; color: #ff0000}
.security	{font-family: \"arial\", arial; font-size:  10pt; font-weight: 700; color: yellow; background-color: #000000;}
a:link		{font-family: \"arial\", arial; font-size: 10pt; font-weight: 600; color: #333399; text-decoration: none}
a:visited	{font-family: \"arial\", arial; font-size: 10pt; font-weight: 600; color: #333399; text-decoration: none}
a:hover		{font-family: \"arial\", arial; font-size: 10pt; font-weight: 600; text-decoration: underline; }
--></STYLE>\n</head>\n";

return($common_style);
}


################################################################################################################
### Create tool log and print appropriate output	 							
###
sub SASHFADD_print_log
{
my $errornote;
if($ERROR eq '1')
	{$errornote = "  At least one ERROR/WARNING was recorded!  Review the SASHFADD_LOG for more information.";}

my $perlver = $];

$output{log} .= ">> Compiling log\n";
my $print_xml_gen = localtime($tool{xml_tstamp});
$output{log_header} = "SAS Hot Fix Analysis, Download and Deployment Tool (SASHFADD) Ver. $tool{version} - $tool{release} (Display: $tool{print_version})\n";
$output{log_header} .= "Report Generated: $CURTIME on PLATFORM:$PLATFORM\n";
$output{log_header} .= "SAS$config{sasrel}_HFADD_data.xml Ver. $tool{xml_version} Generated: $print_xml_gen [$tool{xml_tstamp}]\n";
if($PLATFORM eq 'unix')
	{$output{log_header} .= "Perl Version: $perlver\n";}
$output{log_header} .= "--------------------\n";
$output{log} .= ">> SASHFADD Processing Complete!$errornote\n";

open(DLMLog, ">$filehandle{dlmlog}");
binmode DLMLog;
print DLMLog "$output{log_header}$output{log}\n\n";
close(DLMLog);
}


################################################################################################################
### print final report												
###
sub SASHFADD_print_report
{
my $hfidcount = @HFIDHSTARRAY;
my $nomitcount = @NOMITARRAY;
my $nonencount = @NONENGLISH;

my $keymessage;
if($output{key_header})
	{
	my $citationmessage = "Citation $output{key_header} appears in this report.";
	if($output{citationcount} > 1)
		{$citationmessage = "Citations $output{key_header} appear in this report.";}
	$keymessage .= "<tr><td colspan=\"$RCOLSPAN\">&nbsp;</tr>\n";
	$keymessage .= "<tr><td colspan=\"$RCOLSPAN\" class=\"center\"><span class=\"f1\">$citationmessage  Citation(s) are defined in the <a href=\"#skey\">Citation Key</a>.</span></tr>\n";
	$keymessage .= "<tr><td colspan=\"$RCOLSPAN\" class=\"center\"><span class=\"c1\">It is extremely important for the successful installation of hot fixes that you<br>follow the instructions for citation(s) in this report.  Additional actions,</span>\n";
	$keymessage .= "<br>\n<span class=\"c1\">including post-installation tasks, are NOT performed by the<br>Hot Fix Analysis, Download and Deployment Tool.</span></tr>\n";
	}

my $nonscriptmessage;
if($nomitcount > 0 || ($nonencount > 0 && $config{english_only} ne '1'))
	{
	$nonscriptmessage .= "<tr><td colspan=\"$RCOLSPAN\">&nbsp;</tr>\n";
	$nonscriptmessage .= "<tr><td colspan=\"$RCOLSPAN\" class=\"center\"><span class=\"f1\">This report contains hot fixes which can be downloaded using a generated script<br>\nand also <a href=\"#noscripts\">hot fixes which require manual download</a>.</span></tr>\n";
	}


my $printthis = "<table>\n";
$printthis .= "<tr><td colspan=\"$RCOLSPAN\" class=\"center\"><span class=\"f2\">This report lists the hot fixes that are available for your installed SAS $config{printsasrel} Products.</span></tr>\n";
$printthis .= "<tr><td colspan=\"$RCOLSPAN\" class=\"center\"><span class=\"f1\">See <a href=\"https://support.sas.com/kb/52/718.html\" target=\"52718\">Usage Note 52718</a> for information on software not supported by SASHFADD.</span></tr>\n";
$printthis .= "$keymessage$nonscriptmessage\n";
$printthis .= "<tr><td colspan=\"$RCOLSPAN\">&nbsp;</tr>\n";

if($output{badver})
	{$printthis .= $output{badver};}

my $usage_guide_reference = "See the <a href=\"$USAGE_GUIDE_LINK\" target=\"SASHFADD_guide\">Usage Guide - Review the Hot Fix Report</a> for more information on hot fixes which may appear in this section.</span><br>&nbsp;</tr>\n";

$printthis .= "<tr><td colspan=\"$RCOLSPAN\">&nbsp;</tr>\n";
$printthis .= "<tr><td colspan=\"$RCOLSPAN\" class=\"left graybg\"><span class=\"f1\">&nbsp;<br>Hot fixes in this section of the report may be downloaded and installed individually by clicking the \"Download\" link, or you may choose to download these hot fixes all at once using the generated \"ftp_script\".  \n";
$printthis .= $usage_guide_reference;

if($hfidcount > 0)
	{
	my $thisprod;
	my $lastprod;
	foreach my $hfidhst(@HFIDHSTARRAY)
		{
		$thisprod = $hfdata{$hfidhst}{product_row};
		if($thisprod ne $lastprod)
			{$printthis .= $hfdata{$hfidhst}{product_row};}
		$printthis .= $hfdata{$hfidhst}{hfid_row};
		$lastprod = $thisprod;
		}
	}
else
	{
	$printthis .= "<tr><td colspan=\"5\">&nbsp;</tr>\n";
	my $notequalifier;
	if($nomitcount > 0 || ($nonencount > 0 && $config{english_only} ne '1'))
		{$notequalifier = " available for download and install using scripts generated by the Hot Fix Analysis, Download and Deployment Tool";}
	$printthis .= "<tr><td  colspan=\"5\" class=\"center\" bgcolor=\"#98fb98\"><span class=\"f2\">Your system is currently up-to-date with SAS $config{printsasrel} hot fixes$notequalifier.</span></tr>\n";
	$printthis .= "<tr><td colspan=\"5\">&nbsp;</tr>\n";
	}

if($nomitcount > 0)
	{
	$printthis .= "<tr><td colspan=\"$RCOLSPAN\">&nbsp;<span id=\"noscripts\"></span></tr>\n";
	$printthis .= "<tr><td colspan=\"$RCOLSPAN\" class=\"left graybg\" ><span class=\"f1\">&nbsp;<br>Hot fixes in this section of the report are available only by clicking the \"Download\" link and following the installation instructions in the documentation. \n";
	$printthis .= "If a \"Download\" link does not appear, click the \"Issues Addressed\" link for information on the availability of the hot fix.\n";
	$printthis .= $usage_guide_reference;
	my $thisprod;
	my $lastprod;
	foreach my $hfidhst(@NOMITARRAY)
		{
		$thisprod = $hfdata{$hfidhst}{product_row};
		if($thisprod ne $lastprod)
			{$printthis .= $hfdata{$hfidhst}{product_row};}
		$printthis .= $hfdata{$hfidhst}{hfid_row};
		$lastprod = $thisprod;
		}
	}

if($nonencount > 0 && $config{english_only} eq '0')
	{
	$printthis .= "<tr><td colspan=\"$RCOLSPAN\">&nbsp;<span id=\"nonen\"></span></tr>\n";
	$printthis .= "<tr><td colspan=\"$RCOLSPAN\" class=\"left graybg\"><span class=\"f1\">&nbsp;<br>Hot fixes in this section of the report contain updates only to non-English software components. They are available by clicking the \"Download\" link and following the installation instructions in the documentation.\n";
	$printthis .= $usage_guide_reference;
	my $thisprod;
	my $lastprod;
	foreach my $hfidhst(@NONENGLISH)
		{
		$thisprod = $hfdata{$hfidhst}{product_row};
		if($thisprod ne $lastprod)
			{$printthis .= $hfdata{$hfidhst}{product_row};}
		$printthis .= $hfdata{$hfidhst}{hfid_row};
		
		my $langlist;
		my $langcomma;
		foreach my $nlslang(@NLS2BYTE)
			{
			if($hfdata{$hfidhst}{langs} =~ /$nlslang/)
				{
				$langlist .= "$langcomma$nls{$nlslang}";
				$langcomma = ", ";
				}
			}
		$printthis .= "<tr><td class=\"left\">&nbsp;<td>&nbsp;<td colspan=\"3\" class=\"left\">$langlist";
		$lastprod = $thisprod;
		}
	}

$printthis .= "</table>\n";

if($ERROR ne '1')
	{$printthis =  "$output{report_header}\n$printthis\n$output{report_footer}";}
else
	{
	&SASHFADD_tool_general_error_handling;
	$printthis = "$output{report_header}\n$output{report_error}";
	}
	
$printthis .= "\n<p>&nbsp;<p>&nbsp;<p>&nbsp;<p>&nbsp;\n\n</body>\n</html>\n\n";

if(open(Report, ">$filehandle{report}"))
	{$output{log} .= ">> $filehandle{report} open\n";}
else
	{$output{log} .= ">> %%% ERROR: Unable to open $filehandle{report}\n";}
print Report $printthis;
close(Report);
}

################################################################################################################
### print installed hot fix report										
###
sub SASHFADD_installed_hot_fix_manifest
{
my $printthis =  &SASHFADD_load_common_style('HF_Manifest1');

$printthis .= "
<body>
<table>
<tr><td class=\"center\"><span class=\"h1\">SAS Hot Fixes Currently Installed and Appearing in the SAS Deployment Registry</span></tr>
<tr><td class=\"center\" nowrap>SASHFADD Ver. $tool{print_version} Report Date: $CURTIME</tr>
<tr><td>&nbsp;</tr>
<tr><td class=\"center\">If you installed a \"Container\" hot fix, which delivers updates to multiple SAS Software components 
in one download, then only the hot fixes for the individual components (not the \"Container\" itself) will appear in this report.</tr>
<tr><td>&nbsp;</tr>
<tr><td class=\"center\" nowrap><a href=\"$USAGE_GUIDE_LINK\" target=\"SASHFADD_guide\">Usage Guide</a></tr>
<tr><td>&nbsp;</tr>
</table>\n";

my $printthisXML = "<Installed_Hot_Fixes tool=\"SASHFADD $tool{print_version}\" thisfile=\"$filename{IHFManifestXML}\">\n";

my $manifest_rows;
my $manifest_rowsXML;
foreach my $key(sort keys %reg_ref)   # $key = $host~$product~$prodversion~$maintenance
	{
	if($reg_ref{$key})
		{
		my ($temp_manifest_rows, $temp_manifest_rowsXML) = &SASHFADD_process_hot_fix_manifest_row($key);
		$manifest_rows .= $temp_manifest_rows;
		$manifest_rowsXML .= $temp_manifest_rowsXML;
		}
	}

$printthis .= "\n<table>\n";
if($manifest_rows)
	{
	$printthis .= "<tr><td class=\"left\" nowrap><b>SAS Product</b><td class=\"left\" nowrap><b>Host</b><td class=\"left\" nowrap><b>Installed</b><br><b>Hot Fixes</b></tr>\n<tr><td colspan=\"3\"><hr></tr>\n";
	$printthis .= $manifest_rows;
	$printthisXML .= $manifest_rowsXML;
	}
else
	{$printthis .= "<tr><td nowrap class=\"center\">No Hot Fixes were found in DeploymentRegistry.txt</tr>\n";}
	
$printthis .= "</table>\n<p>&nbsp;<p>&nbsp;<p>&nbsp;<p>&nbsp;\n\n</body>\n</html>\n\n";
$printthisXML .= "</Installed_Hot_Fixes>\n";

if(open(IHFManifest, ">$filehandle{IHFManifest}"))
	{$output{log} .= ">> $filehandle{IHFManifest} open\n";}
else
	{$output{log} .= ">> %%% ERROR: Unable to open $filehandle{IHFManifest}\n";}
print IHFManifest $printthis;
close(IHFManifest);

if(open(IHFManifestXML, ">$filehandle{IHFManifestXML}"))
	{$output{log} .= ">> $filehandle{IHFManifestXML} open\n";}
else
	{$output{log} .= ">> %%% ERROR: Unable to open $filehandle{IHFManifestXML}\n";}
print IHFManifestXML $printthisXML;
close(IHFManifestXML);
}

################################################################################################################
### print installed hot fix report										
###
sub SASHFADD_process_hot_fix_manifest_row
{
my $key = shift;

my $printprodmaint;
if($regMaintenance{$key} > 0)
	{$printprodmaint = "_M$regMaintenance{$key}";}
my $thisproduct = "$regDisplayName{$key} $regVersion{$key}$printprodmaint";

my $hflist;
my $hflistXML;
my $br;
my $comma;
my @installedhfarray = split(/ /, $reg_ref{$key});

my @sortedomstalledhfarray = sort { $a cmp $b } @installedhfarray;

foreach my $hfhst(@sortedomstalledhfarray)
	{
	if($hfhst)
		{
		my @splitA = split(/_/, $hfhst);
		my $thishf = $splitA[0];
		$hflist .= "$br$thishf";
		$br = "\n<br>";
		$hflistXML .= "$comma$thishf";
		$comma = ",";
		}
	}

my $printrow .= "<tr><td class=\"left\" nowrap>$thisproduct<td class=\"left\" nowrap>$host{official}{$regHost{$key}}<td class=\"left\" nowrap>$hflist</tr>\n<tr><td colspan=\"3\"><hr></tr>\n";
my $printrowXML = "<InstalledHotFixes product=\"$thisproduct\" host=\"$host{official}{$regHost{$key}}\" hotfixes=\"$hflistXML\" />\n";

return($printrow, $printrowXML);
}

#														
#														
#	Miscellaneous												
#														
#														

################################################################################################################
### SASHFADD_load_config											
### loads_HFADD configuration data										
###
sub SASHFADD_load_config
{
my $configfile = "SASHFADD.cfg";

if(open(configfile, "$configfile"))
	{$output{log} .= ">> $configfile open\n";}
else
	{$output{log} .= ">> %%% ERROR: Unable to open HFADD configuration file: $configfile\n>>     Default configuration will be used.\n";}

my $sas93overrideflag = 0;
my $sas94overrideflag = 0;
$config{highlight_week} = 0;

my $configline = <configfile>;
while(!eof(configfile))
	{
	chomp($configline);
	$configline =~ s/\s+//g;
	if($configline =~ /^-SAS/i)
		{
		my $sasrelease = $configline;
		$sasrelease =~ s/\W+//g;
		if($sasrelease =~ /93/)
			{
			&SASHFADD_set_release_vars('93','config');
			$output{log} .= "    CONFIG |$configline| sets SAS_RELEASE=$config{sasrel}\n";
			$config{report} .= "<tr><td class=\"left\">-SAS 9.3</tr>\n";
			$sas93overrideflag = 1;
			}
		elsif($sasrelease =~ /94/)
			{
			&SASHFADD_set_release_vars('94','config');
			$output{log} .= "    CONFIG |$configline| sets SAS_RELEASE=$config{sasrel}\n";
			$config{report} .= "<tr><td class=\"left\">-SAS 9.4</tr>\n";
			$sas94overrideflag = 1;
			}
		}
	elsif($configline =~ /^-SILENT/i)
		{
		$config{silent} = 1;
		$output{log} .= "    CONFIG |$configline| activates SILENT MODE\n";
		$OUTPUTNAME = "SASHFADD";
		$config{report} .= "<tr><td class=\"left\">-SILENT</tr>\n";
		}
	elsif($configline =~ /^-GENERATE_ALERT_ONLY_SCRIPTING/i)
		{
		$config{alert_only_scripting} = 1;
		$output{log} .= "    CONFIG |$configline| activates ALERT ONLY SCRIPTING\n";
		$config{report} .= "<tr><td class=\"left\">-GENERATE_ALERT_ONLY_SCRIPTING</tr>\n";
		}
	elsif($configline =~ /^-GENERATE_SCRIPTING_FOR_ALL_ELIGIBLE_HOT_FIXES/i)
		{
		$config{all_eligible_scripting} = 1;
		$output{log} .= "    CONFIG |$configline| activates ALL ELIGIBLE SCRIPTING\n";
		$config{report} .= "<tr><td class=\"left\">-GENERATE_SCRIPTING_FOR_ALL_ELIGIBLE_HOT_FIXES</tr>\n";
		}
	elsif($configline =~ /^-GENERATE_SECURE_SFTP_SCRIPTING/i)
		{
		$config{sftp_secure_scripting} = 1;
		$output{log} .= "    CONFIG |$configline| activates SECURE SFTP SCRIPTING\n";
		$config{report} .= "<tr><td class=\"left\">-GENERATE_SECURE_SFTP_SCRIPTING</tr>\n";
		}
	elsif($configline =~ /^-GENERATE_HOT_FIX_DOWNLOAD_SCRIPTS_USING_BASIC_FTP/i)
		{
		$config{basic_ftp_scripting} = 1;
		$output{log} .= "    CONFIG |$configline| activates BASIC FTP SCRIPTING\n";
		$config{report} .= "<tr><td class=\"left\">-GENERATE_HOT_FIX_DOWNLOAD_SCRIPTS_USING_BASIC_FTP</tr>\n";
		}
	elsif($configline =~ /^-HIGHLIGHT_HOT_FIXES_AVAILABLE_LESS_THAN_/i)
		{
		my $HighlightRequestError;
		if($configline =~ /_4_/)
			{$config{highlight_week} = 4;}
		elsif($configline =~ /_3_/)
			{if(3 > $config{highlight_week}){$config{highlight_week} = 3;}}
		elsif($configline =~ /_2_/)
			{if(2 > $config{highlight_week}){$config{highlight_week} = 2;}}
		elsif($configline =~ /_1_/)
			{if(1 > $config{highlight_week}){$config{highlight_week} = 1;}}
		else
			{$HighlightRequestError= " - Invalid HIGHLIGHT Request... ignored!";}
		$output{log} .= "    CONFIG |$configline| activates HIGHLIGHT$HighlightRequestError\n";
		}
	elsif($configline =~ /^-HOT_FIX_DATA_FILE_MANUAL_DOWNLOAD/i)
		{
		$config{manual_data} = 1;
		$output{log} .= "    CONFIG |$configline| suppresses HOT FIX DATA XML DOWNLOAD\n";
		$config{report} .= "<tr><td class=\"left\">-HOT_FIX_DATA_FILE_MANUAL_DOWNLOAD</tr>\n";
		}
	elsif($configline =~ /^-ENGLISH_ONLY/i)
		{
		$config{english_only} = 1;
		$output{log} .= "    CONFIG |$configline| activates ENGLISH ONLY\n";
		$config{report} .= "<tr><td class=\"left\">-ENGLISH_ONLY</tr>\n";
		}
	elsif($configline =~ /^-USE_DDMMMYYYY_TIME_FORMAT_FOR_DIRECTORY_AND_FILE_NAMES/i)
		{
		$config{date_format_1} = 1;
		$output{log} .= "    CONFIG |$configline| activates DDMMMYYYY FORMAT\n";
		$config{report} .= "<tr><td class=\"left\">-USE_DDMMMYYYY_TIME_FORMAT_FOR_DIRECTORY_AND_FILE_NAMES</tr>\n";
		}
	elsif($configline =~ /^-USE_MODIFIED_SCRIPT_HEADER/i)
		{
		$config{modified_script_header} = 1;
		$output{log} .= "    CONFIG |$configline| activates MODIFIED_SCRIPT_HEADER\n";
		$config{report} .= "<tr><td class=\"left\">-USE_MODIFIED_SCRIPT_HEADER</tr>\n";
		}
	elsif($configline =~ /^-APPLY_ADDITIONAL_DOWNLOAD_COMMAND_OPTIONS/i)
		{
		$config{add_command_line_options} = 1;
		$output{log} .= "    CONFIG |$configline| activates ADDITIONAL COMMAND LINE OPTIONS\n";
		$config{report} .= "<tr><td class=\"left\">-APPLY_ADDITIONAL_DOWNLOAD_COMMAND_OPTIONS</tr>\n";
		}
	$configline = <configfile>;
	}
close(configfile);

my $sasoverrideflagcount = $sas93overrideflag + $sas94overrideflag;
if($sasoverrideflagcount > 1)
	{
	$ERROR = 1;
	$output{log} .= ">> %%% ERROR: More than one release of SAS has been specified in SASHFADD.cfg.\n";
	}

if($config{alert_only_scripting} eq '1' && $config{all_eligible_scripting} eq '1')
	{
	$config{alert_only_scripting} = 0;
	$config{all_eligible_scripting} = 0;	
	$output{log} .= "    CONFIG | ALERT ONLY and ALL ELIGIBLE scripting activated\n";
	}

if($config{sftp_secure_scripting} eq '1' && $config{basic_ftp_scripting} eq '1')
	{
	$config{basic_ftp_scripting} = 0;
	$output{log} .= "    CONFIG | SECURE SFTP scripting activation takes precedence over basic FTP \n";
	$config{report} .= "<tr><td class=\"left\"><b>NOTE:</b> Secure SFTP and basic FTP scripting were both activated in SASHFADD.cfg.  Secure SFTP scripting takes precedence.  Basic FTP will not be used</tr>\n";
	}

if($config{sftp_secure_scripting} eq '1' && $config{modified_script_header} eq '1')
	{
	$config{modified_script_header} = 0;
	$output{log} .= "    CONFIG | SECURE scripting activation takes precedence over MODIFIED_SCRIPT_HEADER \n";
	$config{report} .= "<tr><td class=\"left\"><b>NOTE:</b> Secure FTP and MODIFIED_SCRIPT_HEADER were both activated in SASHFADD.cfg.  Secure FTP scripting takes precedence.  MODIFIED_SCRIPT_HEADER will not be used.</tr>\n";
	}

if($config{modified_script_header} eq '1' && $config{sftp_secure_scripting} ne '1' && $config{basic_ftp_scripting} ne '1')
	{
	my $method = "curl";
	if($PLATFORM eq 'win')
		{$method = "PowerShell";}
	$output{log} .= "    CONFIG | *WARNING* - Use of a Modified Script Header with $method may produce unexpected results.\n";
	$config{report} .= "<tr><td class=\"left\"><span class=\"yellowbg\">WARNING:</span> $method script with a \"modified script header\" may produce unexpected results.</tr>\n";
	print "\nWARNING: $method script with a \"modified script header\" may produce unexpected results.\n";
	}

if($config{highlight_week} > 0)
	{
	my $addS;
	if($config{highlight_week} > 1){$addS = "S";}
	$config{report} .= "<tr><td class=\"left\">-HIGHLIGHT_HOT_FIXES_AVAILABLE_LESS_THAN_$config{highlight_week}_WEEK$addS</tr>\n";
	}

$output{log} .= ">> SASHFADD.cfg processing complete\n";	
}


################################################################################################################
### SASHFADD set printsasrel											
###
sub SASHFADD_set_release_vars
{
my $sasrel = shift;		# 93, 94
my $rel_source = shift;		# config, instqualtool, MF_94_default

if($config{sasrelfrozen} eq '0')
	{
	if($sasrel eq '93')
		{
		$config{sasrel} = "93";
		$config{printsasrel} = "9.3";
		}
	elsif($sasrel eq '94')
		{
		$config{sasrel} = "94";
		$config{printsasrel} = "9.4";
		}
	else
		{
		$ERROR = 1;
		$output{log} .= ">> %%% ERROR: This release of SASHFADD is only compatible with SAS 9.3 and SAS 9.4.  SAS ($sasrel) compatibility error.\n";
		}
	
	if($rel_source eq 'config')
		{
		$config{sasrelfrozen} = 1;
		$config{sasrelsource} = "config";
		$output{log} .= ">> SAS RELEASE: $config{sasrel} (from $rel_source ...will not be over-riden)\n";
		}
	else
		{
		$config{sasrelsource} = "$rel_source";
		$output{log} .= ">> SAS RELEASE: $config{sasrel} (from $rel_source)\n";
		}
	}
}

################################################################################################################
### SASHFADD_load_comments											
###
sub SASHFADD_load_comments
{
$output{log} .= ">> Loading comments\n";

@COMMENTARRAY = ('customdoc','dlpgecmts','nomit','nodownload','iscontainer','alert','security');

$comments{citation_customdoc}  = "D";
$comments{customdoc}  = "Documentation contains special pre-installation, post-installation or other unique instructions not commonly used for hot fix deployment.  Review the documentation carefully to successfully deploy the hot fix.  ";
$comments{customdoc} .= "If [1] also appears next to the \"Issue(s) Addressed\" link, click that link to see important additional note(s) associated with the hot fix.";

$comments{citation_dlpgecmts}  = "1";
$comments{dlpgecmts}  = "Click the \"Issue(s) Addressed\" link to see important note(s) associated with this hot fix.";

$comments{citation_nomit}      = "2";
$comments{nomit}      = "This hot fix may not use the same installation tool as other hot fixes, it may need to be installed separately from other hot fixes, or it may require special settings during installation.  Review all documentation carefully.";

$comments{citation_nodownload} = "3";
$comments{nodownload} = "Click the \"Issue(s) Addressed\" link for information on accessing this hot fix.";

$comments{citation_iscontainer} = "C";
$comments{iscontainer} = "This is a <b>Container</b> Hot Fix, delivering updates to multiple SAS Software components in one download.  View the Documentation for the list of components that will be updated. See \"What is a container hot fix?\" in the <a href=\"https://tshf.sas.com/techsup/download/hotfix/faq.html#container_define\" target=\"hffaq\">Hot Fix FAQ</a> for more information.";

$comments{citation_alert} = "<span class=\"redbold\">A</span>";
$comments{alert} = "At least one ALERT issue is addressed in this hot fix.  View the Issue(s) Addressed for more information.";

$comments{citation_security} = "<span class=\"security\">S</span>";
$comments{security} = "At least one SECURITY issue is addressed in this hot fix.  View the Issue(s) Addressed for more information.";

}


################################################################################################################
### SASHFADD_alert_dependencies											
### @HFIDHSTALERTDEPARRAY contains ALERT hot fixes and their dependent hot fixes (both non-ALERT and ALERT)	
###														
sub SASHFADD_alert_dependencies_01
{
my $usedhfidhstalertlist;
foreach my $hfidhst(@HFIDHSTARRAY)
	{
	if($hfdata{$hfidhst}{alert} eq '1' && $usedhfidhstalertlist !~ / $hfidhst /)
		{
		push(@HFIDHSTALERTDEPARRAY, $hfidhst);
		$usedhfidhstalertlist .= " $hfidhst ";
		if($hfdata{$hfidhst}{deplist})
			{
			my @deplistarray = split(/,/, $hfdata{$hfidhst}{deplist});
			foreach my $dephfhst(@deplistarray)
				{
				if($hfdata{$dephfhst}{md5} && $HFIDHSTLIST =~ / $dephfhst / && $usedhfidhstalertlist !~ / $dephfhst /)
					{
					push(@HFIDHSTALERTDEPARRAY, $dephfhst);
					$usedhfidhstalertlist .= " $dephfhst ";
					}
				}
			}
		}
	}
}

################################################################################################################
### SASHFADD_alert_readme_content										
###
sub SASHFADD_alert_readme_content
{
my $alert_readme_content = 
"Files in the \"DOWNLOAD_\" directory are used for the scripted hot fix download process.  

These files may or may not have \"_ALERT_ONLY\" in their name depending on your selections in the 
SASHFADD.cfg file and whether or not there are hot fixes eligible for installation on your system
that address \"ALERT\" issues.

Refer to the SASHFADD_Usage_Guide for more information on the SASHFADD.cfg file.

Files designated \"_ALERT_ONLY\"
     - should be used to download and install ONLY eligible hot fixes that address one or
       more \"ALERT\" issues.
     - may contain \"non-ALERT\" hot fixes that are dependent on a hot fix that addresses 
       one or more \"ALERT\" issues.

Files NOT designated \"_ALERT_ONLY\":
     - contain hot fixes for BOTH \"ALERT\" and \"non-ALERT\" issues.
     - should be used to download and install ALL eligible hot fixes.\


After the hot fixes are downloaded, they will appear in the \"DEPLOY_\" directory.  
    - For SAS 9.3 and 9.4 these hot fixes can be installed using the SAS Deployment Manager.


Prior to downloading and installing hot fixes, it is extremely important that you review the generated
\"SAS_Hot_Fix_Analysis_Report\".  Pay close attention to hot fixes with a 
[ D ] next to the \"Documentation\" link and follow all pre/post installation instructions contained
in the documentation.\n\n";
return $alert_readme_content;
}

################################################################################################################
### Guarantees that SAS*_HFADD_data.xml is compatible with this version of SASHFADD			
###
sub SASHFADD_check_version_compatibility
{
my $rc = 1;
if($tool{version} eq $tool{xml_version})
	{$output{log} .= ">> \"SAS$config{sasrel}_HFADD_data.xml\" Ver $tool{xml_version} matches SASHFADD Ver $tool{version}.  OK to proceed!\n";}
elsif($OPENDATAFILEERROR)
	{
	print "\n**********\nSASHFADD was unable to locate, download or open a critical hot fix data file.\n\n";
	print "See the \"Troubleshooting\" section of the SASHFADD \"Usage Guide\" for\nmore information.  ";
	print "A link to the SASHFADD Usage Guide is available\nin the generated Analysis Report.\n**********\n";
	}
elsif($tool{version} eq $tool{xml_testmode})
	{
	$output{badver} .= "\n<tr><td colspan=\"5\" class=\"center\"><b>Note</b>: SASHFADD $tool{version} is in \"TestMode\". Tool update/replacement warning deactivated.</tr>\n";
	$output{log} .= ">> \"SAS$config{sasrel}_HFADD_data.xml\" Ver $tool{xml_version} does NOT match SASHFADD Ver $tool{version}, but DOES match testmode:$tool{xml_testmode} -  TESTMODE ON.... OK to proceed!\n";
	}
elsif($tool{xml_version} =~ /\d+/ && $tool{version} ne $tool{xml_version})
	{
	$rc = 0;
	$output{badver} .= "\n<table><tr><td class=\"left\"><span class=\"redbold\">IMPORTANT</span>:\n";
	$output{badver} .= "An updated version of the <a href=\"$TOOL_LINK\">SAS Hot Fix Analysis and Installation tool</a> is available. Please download and install\n"; 
	$output{badver} .= "<a href=\"$TOOL_LINK\">the latest SASHFADD</a> and use this new version to perform your SAS installation analysis.\n";
	$output{badver} .= "</tr></table>\n";
	$output{log} .= ">> %%% ERROR %%%\n\"SAS$config{sasrel}_HFADD_data.xml\" Ver $tool{xml_version} does not match SASHFADD Ver $tool{version}\n\n";
	}
else
	{
	$rc = 0;
	print "\n**********\nAn Unspecified error has occured which is preventing SASHFADD from processing \"SAS$config{sasrel}_HFADD_data.xml\".\n\n";
	print "See the \"Troubleshooting\" section of the SASHFADD \"Usage Guide\" for\nmore information.  ";
	print "A link to the SASHFADD Usage Guide is available\nin the generated Analysis Report.\n**********\n";
	$output{badver} .= "\n<table><tr><td class=\"left\"><span class=\"redbold\">IMPORTANT</span>:\n";
	$output{badver} .= "An Unspecified error has occured which is preventing SASHFADD from processing \"SAS$config{sasrel}_HFADD_data.xml\".<br>\n"; 
	$output{badver} .= "See the \"Troubleshooting\" section of the SASHFADD <a href=\"$USAGE_GUIDE_LINK\" target=\"SASHFADD_guide\">Usage Guide</a> for more information.\n";
	$output{badver} .= "</tr></table>\n";
	$output{log} .= ">> %%% ERROR %%%\nAn unspecified error occured during download/processing of \"SAS$config{sasrel}_HFADD_data.xml\".\n\n";
	}

if($rc eq '0')
	{
	&SASHFADD_initialize_report;
	if(open(Report, ">$filehandle{report}"))
		{$output{log} .= ">> $filehandle{report} open\n";}
	else
		{$output{log} .= ">> %%% ERROR: Unable to open $filehandle{report}\n";}
	print Report $output{report_header};
	print Report $output{badver};
	close(Report);
	&SASHFADD_print_log;

	print "\n**********\nAn updated version of SASHFADD is available.  Please download and install the updated version.\n";  
	print "A link to the SASHFADD download site is available in the generated Analysis Report.\n**********\n";
	if($PLATFORM eq 'win')
		{
		print "Press \"Enter\" to close this window.";
		my $exitcode = <>;
		}
	exit(0);
	}
else
	{return $rc;}
}

################################################################################################################
### Generates a "readable" time stamp that can be used for file and directory names instead of EPOCH		
### $CURTIME in = Fri Jan 14 08:39:07 2011
### out = 14Jan2011_08.39.07
###
sub SASHFADD_generate_displaytstamp
{
my $displaytstamp;

my @splitA = split(/\s+/, $CURTIME);
my $time = $splitA[3];
$time =~ s/\:/\./g;

my $day = (localtime)[3];
if($day <= 9)
	{$day = "0$day";}
my $mon = (localtime)[4] + 1;
my $year = (localtime)[5] + 1900;
$displaytstamp = "${year}_${mon}_${day}_$time";	

if($config{date_format_1} eq '1')
	{
	$mon = $splitA[1];
	$day = $splitA[2];
	$year = $splitA[4];
	$displaytstamp = "$day$mon${year}_$time";
	}

return($displaytstamp);
}

################################################################################################################
### Generates a "readable" time stamp that can be used for file and directory names instead of EPOCH		
###
sub SASHFADD_outputname_prompt
{
print "Enter a descriptive name of the machine that contains the SAS deployment\nor press \"Enter\" to accept a default name: ";
$OUTPUTNAME = <>;
chomp($OUTPUTNAME);

if($OUTPUTNAME =~ /\W+/)
	{
	print "\nOnly alphanumeric characters and underscores can be accepted.\nPlease try again.\n\n";
	&SASHFADD_outputname_prompt;
	}
elsif($OUTPUTNAME !~ /\w+/)
	{$OUTPUTNAME = "SASHFADD";}
}

################################################################################################################
### Produce ERROR message for the Report page.									
###
sub SASHFADD_tool_general_error_handling
{
$output{report_error} .= "
<table><tr><td class=\"left\"><span class=\"redbold\">ERROR</span>:<br>
An error occured during the generation of this report.  Please see $filehandle{dlmlog} for details.
</tr></table>\n";
}

################################################################################################################
### Create the filenames and file handles for all the output.							
### 
sub SASHFADD_create_output_structure
{
$output{log} .= ">> Creating output directory structure\n";
my $pslash = $pslash{$PLATFORM};

my $outputdir = "${OUTPUTNAME}_${DISPLAYTSTAMP}";
my $syscommand = "mkdir $outputdir";
my $rc = system($syscommand);

$dirname{download} = "DOWNLOAD_$outputdir";
$dirname{deploy} = "DEPLOY_$outputdir";
$dirname{log} = "LOG_$outputdir";

$filename{report} = "SAS_Hot_Fix_Analysis_Report_${DISPLAYTSTAMP}.html";
$filename{dlmlog} = "SASHFADD_LOG_${DISPLAYTSTAMP}.txt";

if($PLATFORM eq 'win')
	{
	if($config{sftp_secure_scripting} eq '1')
		{
		$filename{dlmftpbat} = "sftp_script.bat";
		$filename{dlmftpbatALERT} = "sftp_script_ALERT_ONLY.bat";
		$filename{dlmftp} = "sftp_script.txt";
		$filename{dlmftpALERT} = "sftp_script_ALERT_ONLY.txt";
		}
	elsif($config{basic_ftp_scripting} eq '1')
		{
		$filename{dlmftpbat} = "ftp_script.bat";
		$filename{dlmftpbatALERT} = "ftp_script_ALERT_ONLY.bat";
		$filename{dlmftp} = "ftp_script.txt";
		$filename{dlmftpALERT} = "ftp_script_ALERT_ONLY.txt";
		}
	else 
		{
		$filename{dlmpower} = "powershell_script.bat";
		$filename{dlmpowerALERT} = "powershell_script_ALERT_ONLY.bat";
		}
	}
elsif($PLATFORM eq 'unix')
	{
	if($config{sftp_secure_scripting} eq '1') 
		{
		$filename{dlmftp} = "sftp_script.sh";
		$filename{dlmftpALERT} = "sftp_script_ALERT_ONLY.sh";
		$filename{sftptxt} = "sftp.txt";
		$filename{sftpALERTtxt} = "sftp_ALERT_ONLY.txt";
		}
	elsif($config{basic_ftp_scripting} eq '1')
		{
		$filename{dlmftp} = "ftp_script.sh";
		$filename{dlmftpALERT} = "ftp_script_ALERT_ONLY.sh";
		}
	else
		{
		$filename{dlmcurl} = "curl_script.sh";
		$filename{dlmcurlALERT} = "curl_script_ALERT_ONLY.sh";
		}
	}

$filename{md5list} = "MD5_checksums.txt";
$filename{md5listALERT} = "MD5_checksums_ALERT_ONLY.txt";
$filename{alert_only_readme} = "ALERT_README.txt";
$filename{sas93_94_install_readme} = "INSTALL_README.txt";
$filename{IHFManifest} = "Installed_Hot_Fixes_${OUTPUTNAME}_${DISPLAYTSTAMP}.html";
$filename{IHFManifestXML} = "Installed_Hot_Fixes_${OUTPUTNAME}_${DISPLAYTSTAMP}.xml";


if($rc eq '0')
	{
	$filehandle{printoutputdir} = $outputdir;
	my $syscommand = "mkdir $outputdir${pslash}$dirname{download}";
	my $subrc = system($syscommand);
	$syscommand = "mkdir $outputdir${pslash}$dirname{deploy}";
	$subrc = system($syscommand);
	$syscommand = "mkdir $outputdir${pslash}$dirname{log}";
	$subrc = system($syscommand);
	}

if($rc ne '0')
	{
	$filehandle{printoutputdir} = "Current working directory";
	$output{log} .= ">> Bad return code creating $outputdir\n   All output will be writen to current working directory\n\n";
	$outputdir = undef;
	$filehandle{dlmlog} = "$OUTPUTNAME.$DISPLAYTSTAMP.$filename{dlmlog}";
	$filehandle{dlmftp} = "$OUTPUTNAME.$DISPLAYTSTAMP.$filename{dlmftp}";
	$filehandle{dlmftpALERT} = "$OUTPUTNAME.$DISPLAYTSTAMP.$filename{dlmftpALERT}";
	$filehandle{dlmftpbat} = "$OUTPUTNAME.$DISPLAYTSTAMP.$filename{dlmftpbat}";
	$filehandle{dlmftpbatALERT} = "$OUTPUTNAME.$DISPLAYTSTAMP.$filename{dlmftpbatALERT}";
	$filehandle{sftptxt} = "$OUTPUTNAME.$DISPLAYTSTAMP.$filename{sftptxt}";
	$filehandle{sftpALERTtxt} = "$OUTPUTNAME.$DISPLAYTSTAMP.$filename{sftpALERTtxt}";
	$filehandle{dlmpower} = "$OUTPUTNAME.$DISPLAYTSTAMP.$filename{dlmpower}";
	$filehandle{dlmpowerALERT} = "$OUTPUTNAME.$DISPLAYTSTAMP.$filename{dlmpowerALERT}";
	$filehandle{dlmcurl} = "$OUTPUTNAME.$DISPLAYTSTAMP.$filename{dlmcurl}";
	$filehandle{dlmcurlALERT} = "$OUTPUTNAME.$DISPLAYTSTAMP.$filename{dlmcurlALERT}";
	$filehandle{md5} = "$OUTPUTNAME.$DISPLAYTSTAMP.$filename{md5list}";
	$filehandle{md5ALERT} = "$OUTPUTNAME.$DISPLAYTSTAMP.$filename{md5listALERT}";
	$filehandle{alert_readme_downloadtools} = "$OUTPUTNAME.$DISPLAYTSTAMP.$filename{alert_only_readme}";
	$filehandle{alert_readme_deploytools} = "$OUTPUTNAME.$DISPLAYTSTAMP.$filename{alert_only_readme}";
	$filehandle{sas93_94_install_readme_deploytools} = "$OUTPUTNAME.$DISPLAYTSTAMP.$filename{sas93_94_install_readme}";
	$filehandle{IHFManifest} = "$OUTPUTNAME.$DISPLAYTSTAMP.$filename{IHFManifest}";
	$filehandle{IHFManifestXML} = "$OUTPUTNAME.$DISPLAYTSTAMP.$filename{IHFManifestXML}";
	}
else
	{
	$filehandle{report} = "$outputdir${pslash}$filename{report}";
	$output{log} .= ">> $outputdir created successfully\n";
	$filehandle{dlmlog} = "$outputdir${pslash}$dirname{log}${pslash}$filename{dlmlog}";
	$filehandle{dlmlogALERT} = "$outputdir${pslash}$dirname{log}${pslash}$filename{dlmlogALERT}";
	$filehandle{dlmftp} = "$outputdir${pslash}$dirname{download}${pslash}$filename{dlmftp}";
	$filehandle{dlmftpALERT} = "$outputdir${pslash}$dirname{download}${pslash}$filename{dlmftpALERT}";
	$filehandle{dlmftpbat} = "$outputdir${pslash}$dirname{download}${pslash}$filename{dlmftpbat}";
	$filehandle{dlmftpbatALERT} = "$outputdir${pslash}$dirname{download}${pslash}$filename{dlmftpbatALERT}";
	$filehandle{sftptxt} = "$outputdir${pslash}$dirname{download}${pslash}$filename{sftptxt}";
	$filehandle{sftpALERTtxt} = "$outputdir${pslash}$dirname{download}${pslash}$filename{sftpALERTtxt}";
	$filehandle{dlmpower} = "$outputdir${pslash}$dirname{download}${pslash}$filename{dlmpower}";
	$filehandle{dlmpowerALERT} = "$outputdir${pslash}$dirname{download}${pslash}$filename{dlmpowerALERT}";
	$filehandle{dlmcurl} = "$outputdir${pslash}$dirname{download}${pslash}$filename{dlmcurl}";
	$filehandle{dlmcurlALERT} = "$outputdir${pslash}$dirname{download}${pslash}$filename{dlmcurlALERT}";
	$filehandle{md5} = "$outputdir${pslash}$dirname{download}${pslash}$filename{md5list}";
	$filehandle{md5ALERT} = "$outputdir${pslash}$dirname{download}${pslash}$filename{md5listALERT}";
	$filehandle{alert_readme_downloadtools} = "$outputdir${pslash}$dirname{download}${pslash}$filename{alert_only_readme}";
	$filehandle{alert_readme_deploytools} = "$outputdir${pslash}$dirname{deploy}${pslash}$filename{alert_only_readme}";
	$filehandle{sas93_94_install_readme_deploytools} = "$outputdir${pslash}$dirname{deploy}${pslash}$filename{sas93_94_install_readme}";
	$filehandle{IHFManifest} = "$outputdir${pslash}$dirname{log}${pslash}$filename{IHFManifest}";
	$filehandle{IHFManifestXML} = "$outputdir${pslash}$dirname{log}${pslash}$filename{IHFManifestXML}";
	}
}
